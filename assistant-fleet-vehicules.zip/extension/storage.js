/**
 * storage.js
 * Couche d'accès aux données (Model dans notre architecture MVC).
 * Toutes les données vivent dans chrome.storage.local : aucune fuite vers
 * l'extérieur, tout reste sur le poste du collaborateur.
 */

const KEYS = {
  AGREEMENTS: "agreements",
  CHAT_HISTORY: "chatHistory",
  PINNED: "pinnedProviders",
  SETTINGS: "settings",
  VEHICLES: "vehicles",
  FICHES: "fiches",
};

function uid(prefix = "agr") {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

// Normalise une immatriculation pour la comparaison (accents/casse/espaces/tirets).
function normalizePlate(plate) {
  return (plate || "")
    .toString()
    .toUpperCase()
    .replace(/[\s-]+/g, "")
    .trim();
}

async function getAll(key, fallback) {
  const data = await chrome.storage.local.get(key);
  return data[key] !== undefined ? data[key] : fallback;
}

async function setAll(key, value) {
  await chrome.storage.local.set({ [key]: value });
  return value;
}

const Store = {
  // ---------- Accords ----------
  async listAgreements() {
    return getAll(KEYS.AGREEMENTS, []);
  },

  async getAgreement(id) {
    const list = await this.listAgreements();
    return list.find((a) => a.id === id) || null;
  },

  async saveAgreement(agreement) {
    const list = await this.listAgreements();
    if (agreement.id) {
      const idx = list.findIndex((a) => a.id === agreement.id);
      if (idx >= 0) {
        list[idx] = { ...list[idx], ...agreement };
      } else {
        list.push(agreement);
      }
    } else {
      agreement.id = uid();
      agreement.createdAt = new Date().toISOString();
      list.push(agreement);
    }
    await setAll(KEYS.AGREEMENTS, list);
    return agreement;
  },

  async deleteAgreement(id) {
    const list = await this.listAgreements();
    const next = list.filter((a) => a.id !== id);
    await setAll(KEYS.AGREEMENTS, next);
    return next;
  },

  async togglePin(id) {
    const list = await this.listAgreements();
    const idx = list.findIndex((a) => a.id === id);
    if (idx >= 0) {
      list[idx].pinned = !list[idx].pinned;
      await setAll(KEYS.AGREEMENTS, list);
    }
    return list;
  },

  // ---------- Historique de chat ----------
  async listHistory() {
    return getAll(KEYS.CHAT_HISTORY, []);
  },

  async appendHistory(entry) {
    const history = await this.listHistory();
    history.push({ ...entry, id: uid(), date: new Date().toISOString() });
    // on garde un historique raisonnable (500 derniers échanges)
    const trimmed = history.slice(-500);
    await setAll(KEYS.CHAT_HISTORY, trimmed);
    return trimmed;
  },

  async clearHistory() {
    await setAll(KEYS.CHAT_HISTORY, []);
  },

  // ---------- Paramètres (ex: clé API IA optionnelle) ----------
  async getSettings() {
    return getAll(KEYS.SETTINGS, { aiProvider: "local", openaiApiKey: "" });
  },

  async saveSettings(settings) {
    const current = await this.getSettings();
    const next = { ...current, ...settings };
    await setAll(KEYS.SETTINGS, next);
    return next;
  },

  // ---------- Stats ----------
  async computeDashboard() {
    const list = await this.listAgreements();
    const now = new Date();
    const in30 = new Date(now.getTime() + 30 * 24 * 3600 * 1000);
    const categories = new Set(list.map((a) => a.category).filter(Boolean));
    const providers = new Set(list.map((a) => a.provider).filter(Boolean));
    const expiringSoon = list.filter((a) => {
      if (!a.endDate) return false;
      const end = new Date(a.endDate);
      return end >= now && end <= in30;
    });
    const vehicles = await this.listVehicles();
    const fiches = await this.listFiches();
    return {
      totalAgreements: list.length,
      totalProviders: providers.size,
      totalCategories: categories.size,
      expiringSoon,
      totalVehicles: vehicles.length,
      totalFiches: fiches.length,
    };
  },

  // ---------- Véhicules ----------
  async listVehicles() {
    return getAll(KEYS.VEHICLES, []);
  },

  async getVehicle(id) {
    const list = await this.listVehicles();
    return list.find((v) => v.id === id) || null;
  },

  async findVehicleByPlate(plate) {
    const target = normalizePlate(plate);
    if (!target) return null;
    const list = await this.listVehicles();
    return list.find((v) => normalizePlate(v.plate) === target) || null;
  },

  async saveVehicle(vehicle) {
    const list = await this.listVehicles();
    if (vehicle.id) {
      const idx = list.findIndex((v) => v.id === vehicle.id);
      if (idx >= 0) {
        list[idx] = { ...list[idx], ...vehicle };
      } else {
        list.push(vehicle);
      }
    } else {
      vehicle.id = uid("veh");
      vehicle.createdAt = new Date().toISOString();
      list.push(vehicle);
    }
    await setAll(KEYS.VEHICLES, list);
    return vehicle;
  },

  async deleteVehicle(id) {
    const list = await this.listVehicles();
    const next = list.filter((v) => v.id !== id);
    await setAll(KEYS.VEHICLES, next);
    return next;
  },

  // ---------- Fiches d'exploitation (par client) ----------
  async listFiches() {
    return getAll(KEYS.FICHES, []);
  },

  async getFiche(id) {
    const list = await this.listFiches();
    return list.find((f) => f.id === id) || null;
  },

  async getFicheForVehicle(vehicle) {
    if (!vehicle) return null;
    if (vehicle.ficheId) {
      const byId = await this.getFiche(vehicle.ficheId);
      if (byId) return byId;
    }
    if (!vehicle.client) return null;
    const list = await this.listFiches();
    const norm = vehicle.client.trim().toLowerCase();
    return list.find((f) => (f.client || "").trim().toLowerCase() === norm) || null;
  },

  async saveFiche(fiche) {
    const list = await this.listFiches();
    if (fiche.id) {
      const idx = list.findIndex((f) => f.id === fiche.id);
      if (idx >= 0) {
        list[idx] = { ...list[idx], ...fiche };
      } else {
        list.push(fiche);
      }
    } else {
      fiche.id = uid("fic");
      fiche.createdAt = new Date().toISOString();
      list.push(fiche);
    }
    await setAll(KEYS.FICHES, list);
    return fiche;
  },

  async deleteFiche(id) {
    const list = await this.listFiches();
    const next = list.filter((f) => f.id !== id);
    await setAll(KEYS.FICHES, next);
    return next;
  },
};

// Exposé pour les autres scripts de l'extension (popup, admin, background)
self.Store = Store;
self.STORAGE_KEYS = KEYS;
self.normalizePlate = normalizePlate;
