/**
 * garagefinder.js
 * Recherche de garages à proximité pour l'entretien d'un véhicule.
 *
 * Sources de données utilisées (gratuites, sans clé API) :
 * - Nominatim (OpenStreetMap) pour géocoder une ville saisie au clavier.
 * - Overpass API (OpenStreetMap) pour lister les garages/concessions à
 *   proximité d'un point (nom, adresse, téléphone, site web, horaires,
 *   marques vendues quand elles sont renseignées dans OSM).
 *
 * Limite honnête à connaître : contrairement à Google Places (payant),
 * OpenStreetMap ne fournit ni note moyenne/avis clients, ni prix estimatif
 * de révision. Ces deux champs ne sont donc affichés que quand
 * l'information existe réellement (ex. via vos propres accords
 * fournisseurs, qui contiennent de vraies remises négociées) — on
 * n'invente jamais de note ou de prix.
 */

const OVERPASS_ENDPOINT = "https://overpass-api.de/api/interpreter";
const NOMINATIM_ENDPOINT = "https://nominatim.openstreetmap.org/search";
const SEARCH_RADIUS_M = 15000; // 15 km, ajustable si besoin

function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/** Géocode une ville saisie au clavier (ex. "Gennevilliers") en lat/lon. */
async function geocodeCity(cityText) {
  const url = `${NOMINATIM_ENDPOINT}?format=json&limit=1&countrycodes=fr&q=${encodeURIComponent(cityText)}`;
  const res = await fetch(url, { headers: { Accept: "application/json" } });
  if (!res.ok) throw new Error("Géocodage indisponible pour le moment.");
  const data = await res.json();
  if (!data.length) throw new Error(`Ville introuvable : « ${cityText} ».`);
  return { lat: parseFloat(data[0].lat), lon: parseFloat(data[0].lon), label: data[0].display_name };
}

/** Demande la position GPS du navigateur (nécessite l'autorisation du collaborateur). */
function getBrowserPosition() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("La géolocalisation n'est pas disponible sur cet appareil."));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lon: pos.coords.longitude, label: "Position actuelle" }),
      (err) => reject(new Error(err.code === 1 ? "Localisation refusée. Indiquez plutôt votre ville." : "Impossible de récupérer la position.")),
      { enableHighAccuracy: false, timeout: 8000, maximumAge: 5 * 60 * 1000 }
    );
  });
}

function buildOverpassQuery(lat, lon, radiusM) {
  return `
    [out:json][timeout:25];
    (
      node["shop"="car_repair"](around:${radiusM},${lat},${lon});
      way["shop"="car_repair"](around:${radiusM},${lat},${lon});
      node["shop"="car"](around:${radiusM},${lat},${lon});
      way["shop"="car"](around:${radiusM},${lat},${lon});
    );
    out center tags;
  `;
}

function tagAddress(tags) {
  const parts = [
    [tags["addr:housenumber"], tags["addr:street"]].filter(Boolean).join(" "),
    tags["addr:postcode"],
    tags["addr:city"],
  ].filter(Boolean);
  return parts.join(", ");
}

function parseOpeningHours(raw) {
  // OSM utilise une syntaxe compacte (ex. "Mo-Fr 08:00-12:00,14:00-18:00").
  // On l'affiche telle quelle : la reformater fiablement demanderait un
  // vrai parseur opening_hours, hors scope ici.
  return raw || null;
}

async function queryOverpassGarages(lat, lon, radiusM = SEARCH_RADIUS_M) {
  const query = buildOverpassQuery(lat, lon, radiusM);
  const res = await fetch(OVERPASS_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: "data=" + encodeURIComponent(query),
  });
  if (!res.ok) throw new Error("Recherche de garages indisponible pour le moment (Overpass API).");
  const data = await res.json();

  const seen = new Set();
  const garages = [];
  for (const el of data.elements || []) {
    const tags = el.tags || {};
    const name = tags.name;
    if (!name) continue; // sans nom, inexploitable pour l'utilisateur
    const glat = el.lat ?? el.center?.lat;
    const glon = el.lon ?? el.center?.lon;
    if (glat == null || glon == null) continue;

    const key = `${name}|${glat.toFixed(4)}|${glon.toFixed(4)}`;
    if (seen.has(key)) continue;
    seen.add(key);

    garages.push({
      id: `osm_${el.type}_${el.id}`,
      name,
      address: tagAddress(tags),
      phone: tags.phone || tags["contact:phone"] || null,
      email: tags.email || tags["contact:email"] || null,
      website: tags.website || tags["contact:website"] || null,
      hours: parseOpeningHours(tags.opening_hours),
      brandTag: tags.brand || null,
      isOfficialDealer: tags.shop === "car", // concessionnaire de marque
      lat: glat,
      lon: glon,
      distanceKm: haversineKm(lat, lon, glat, glon),
      source: "osm",
    });
  }
  return garages;
}

// Rapproche les résultats OSM des accords fournisseurs déjà négociés
// (données de confiance : vraies remises, vrai téléphone/adresse saisis par
// l'utilisateur) pour enrichir l'affichage quand un même prestataire existe
// dans les deux sources.
function enrichWithLocalAgreements(garages, agreements) {
  const normName = (s) => (s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
  return garages.map((g) => {
    const match = agreements.find((a) => {
      const base = normName(a.provider).split(" (")[0];
      return base && normName(g.name).includes(base);
    });
    if (!match) return g;
    return {
      ...g,
      negotiatedAgreement: match,
      phone: match.phone || g.phone,
      address: match.address || g.address,
    };
  });
}

// Score de pertinence : concession officielle de la marque du véhicule >
// prestataire déjà négocié en interne > garage spécialisé dans la marque >
// concession d'une autre marque > garage multimarque générique.
function scoreGarage(garage, vehicle) {
  const brand = (vehicle?.brand || "").toLowerCase();
  const gBrand = (garage.brandTag || garage.name || "").toLowerCase();
  let score = 0;
  if (garage.negotiatedAgreement) score += 40; // prestataire déjà vérifié par l'utilisateur
  if (garage.isOfficialDealer && brand && gBrand.includes(brand)) score += 100; // concession officielle de la marque
  else if (brand && gBrand.includes(brand)) score += 60; // spécialiste identifié de la marque
  else if (garage.isOfficialDealer) score += 20; // concession d'une autre marque
  else score += 10; // garage multimarque générique
  return score;
}

function reasonLabel(garage, vehicle) {
  const brand = (vehicle?.brand || "").toLowerCase();
  const gBrand = (garage.brandTag || garage.name || "").toLowerCase();
  if (garage.negotiatedAgreement) return "Prestataire négocié";
  if (garage.isOfficialDealer && brand && gBrand.includes(brand)) return "Concession officielle";
  if (brand && gBrand.includes(brand)) return "Spécialiste de la marque";
  if (garage.isOfficialDealer) return "Concession (autre marque)";
  return "Garage multimarque";
}

/**
 * Point d'entrée principal : trouve et classe les garages pertinents pour
 * un véhicule autour d'une position donnée.
 * @param {string} [requireBrand] - si fourni (règle de marque exclusive,
 *   ex. "Iveco"), ne retourne QUE les concessions officielles de cette
 *   marque : aucune alternative n'est proposée.
 */
async function findGarages({ position, vehicle, agreements, requireBrand }) {
  let garages = await queryOverpassGarages(position.lat, position.lon);
  garages = enrichWithLocalAgreements(garages, agreements || []);

  if (requireBrand) {
    const nb = requireBrand.toLowerCase();
    garages = garages.filter((g) => g.isOfficialDealer && (g.brandTag || g.name || "").toLowerCase().includes(nb));
    garages = garages.map((g) => ({ ...g, score: 100, reason: "Concession officielle (imposée)" }));
    garages.sort((a, b) => a.distanceKm - b.distanceKm);
    return garages.slice(0, 12);
  }

  garages = garages.map((g) => ({ ...g, score: scoreGarage(g, vehicle), reason: reasonLabel(g, vehicle) }));
  // Tri : 1) compatibilité (score), 2) distance. La note client et la
  // disponibilité en temps réel ne sont pas disponibles via une source
  // gratuite — voir la remarque en tête de fichier.
  garages.sort((a, b) => (b.score !== a.score ? b.score - a.score : a.distanceKm - b.distanceKm));
  return garages.slice(0, 12);
}

self.GarageFinder = {
  geocodeCity,
  getBrowserPosition,
  findGarages,
  haversineKm,
};
