/**
 * admin.js
 * Contrôleur de la page d'administration : liste/filtre, création,
 * édition, suppression des accords, et réglages du moteur IA.
 */

const tabs = {
  list: document.getElementById("tab-list"),
  form: document.getElementById("tab-form"),
  vehicles: document.getElementById("tab-vehicles"),
  vehicleForm: document.getElementById("tab-vehicleForm"),
  fiches: document.getElementById("tab-fiches"),
  ficheForm: document.getElementById("tab-ficheForm"),
  importData: document.getElementById("tab-importData"),
  brandRules: document.getElementById("tab-brandRules"),
  brandRuleForm: document.getElementById("tab-brandRuleForm"),
  settings: document.getElementById("tab-settings"),
};

function showTab(name) {
  Object.entries(tabs).forEach(([key, el]) => el.classList.toggle("hidden", key !== name));
  document.querySelectorAll(".nav-item").forEach((btn) =>
    btn.classList.toggle("active", btn.dataset.tab === name)
  );
}

document.querySelectorAll(".nav-item").forEach((btn) =>
  btn.addEventListener("click", async () => {
    showTab(btn.dataset.tab);
    if (btn.dataset.tab === "form") resetForm();
    if (btn.dataset.tab === "vehicleForm") await resetVehicleForm();
    if (btn.dataset.tab === "ficheForm") await resetFicheForm();
    if (btn.dataset.tab === "brandRuleForm") await resetBrandRuleForm();
  })
);

function escapeHtml(str) {
  const d = document.createElement("div");
  d.textContent = str ?? "";
  return d.innerHTML;
}

function parseListField(value) {
  return value
    .split(/[\n,]/)
    .map((s) => s.trim())
    .filter(Boolean);
}

async function refreshSideStats() {
  const stats = await Store.computeDashboard();
  document.getElementById("sideStats").innerHTML = `
    <div><strong>${stats.totalAgreements}</strong> accords</div>
    <div><strong>${stats.totalProviders}</strong> prestataires</div>
    <div><strong>${stats.expiringSoon.length}</strong> expirent sous 30j</div>
    <div><strong>${stats.totalVehicles}</strong> véhicules</div>
    <div><strong>${stats.totalFiches}</strong> fiches clients</div>
    <div><strong>${stats.totalBrandRules}</strong> règles de marque</div>
  `;
}

async function renderList(filter = "") {
  const grid = document.getElementById("agreementGrid");
  const list = await Store.listAgreements();
  const norm = filter.trim().toLowerCase();

  const filtered = norm
    ? list.filter((a) => {
        const haystack = [a.provider, a.category, ...(a.keywords || []), ...(a.brands || [])]
          .join(" ")
          .toLowerCase();
        return haystack.includes(norm);
      })
    : list;

  grid.innerHTML = filtered.length
    ? filtered
        .map(
          (a) => `
    <div class="agreement-card">
      <div class="agreement-card-header">
        <div>
          <div class="agreement-card-title">${escapeHtml(a.provider)}</div>
          <div class="agreement-card-cat">${escapeHtml(a.category || "")}</div>
        </div>
        <span class="pill">Priorité ${a.priority ?? 0}${a.pinned ? " · ★" : ""}</span>
      </div>
      ${a.discount ? `<div class="agreement-card-discount">${escapeHtml(a.discount)}</div>` : ""}
      <div class="agreement-card-keywords">
        ${(a.keywords || []).slice(0, 8).map((k) => `<span class="keyword-tag">${escapeHtml(k)}</span>`).join("")}
      </div>
      <div class="agreement-card-dates">
        ${a.startDate ? `Du ${a.startDate}` : ""} ${a.endDate ? `au ${a.endDate}` : ""}
      </div>
      <div class="agreement-card-actions">
        <button class="btn btn-ghost" data-action="edit" data-id="${a.id}">✎ Modifier</button>
        <button class="btn btn-danger-ghost" data-action="delete" data-id="${a.id}">🗑 Supprimer</button>
      </div>
    </div>`
        )
        .join("")
    : `<div class="empty-hint">Aucun accord ${norm ? "ne correspond à ce filtre" : "enregistré pour le moment"}.<br/>Cliquez sur « Ajouter un accord » pour commencer.</div>`;

  grid.querySelectorAll("[data-action]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.id;
      if (btn.dataset.action === "edit") {
        const agreement = await Store.getAgreement(id);
        fillForm(agreement);
        showTab("form");
      } else if (btn.dataset.action === "delete") {
        if (confirm("Supprimer définitivement cet accord ?")) {
          await Store.deleteAgreement(id);
          await renderList(document.getElementById("filterInput").value);
          await refreshSideStats();
        }
      }
    });
  });
}

document.getElementById("filterInput").addEventListener("input", (e) => renderList(e.target.value));

// ---------------- Formulaire ----------------
const formFields = [
  "id", "provider", "category", "discount", "priority",
  "startDate", "endDate", "keywords", "brands", "services",
  "conditions", "comments", "pdfPath",
];

function resetForm() {
  document.getElementById("formTitle").textContent = "Ajouter un accord";
  document.getElementById("agreementForm").reset();
  document.getElementById("f-id").value = "";
  document.getElementById("f-priority").value = 5;
}

function fillForm(a) {
  document.getElementById("formTitle").textContent = `Modifier « ${a.provider} »`;
  document.getElementById("f-id").value = a.id;
  document.getElementById("f-provider").value = a.provider || "";
  document.getElementById("f-category").value = a.category || "";
  document.getElementById("f-discount").value = a.discount || "";
  document.getElementById("f-priority").value = a.priority ?? 5;
  document.getElementById("f-startDate").value = a.startDate || "";
  document.getElementById("f-endDate").value = a.endDate || "";
  document.getElementById("f-keywords").value = (a.keywords || []).join("\n");
  document.getElementById("f-brands").value = (a.brands || []).join(", ");
  document.getElementById("f-services").value = (a.services || []).join(", ");
  document.getElementById("f-conditions").value = a.conditions || "";
  document.getElementById("f-comments").value = a.comments || "";
  document.getElementById("f-phone").value = a.phone || "";
  document.getElementById("f-address").value = a.address || "";
  document.getElementById("f-pdfPath").value = a.pdfPath || "";
}

document.getElementById("cancelFormBtn").addEventListener("click", () => {
  showTab("list");
});

document.getElementById("agreementForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const agreement = {
    id: document.getElementById("f-id").value || undefined,
    provider: document.getElementById("f-provider").value.trim(),
    category: document.getElementById("f-category").value.trim(),
    discount: document.getElementById("f-discount").value.trim(),
    priority: Number(document.getElementById("f-priority").value) || 0,
    startDate: document.getElementById("f-startDate").value,
    endDate: document.getElementById("f-endDate").value,
    keywords: parseListField(document.getElementById("f-keywords").value),
    brands: parseListField(document.getElementById("f-brands").value),
    services: parseListField(document.getElementById("f-services").value),
    conditions: document.getElementById("f-conditions").value.trim(),
    comments: document.getElementById("f-comments").value.trim(),
    phone: document.getElementById("f-phone").value.trim(),
    address: document.getElementById("f-address").value.trim(),
    pdfPath: document.getElementById("f-pdfPath").value.trim(),
  };
  await Store.saveAgreement(agreement);
  await renderList(document.getElementById("filterInput").value);
  await refreshSideStats();
  showTab("list");
});

// ============================================================
// VÉHICULES
// ============================================================
const GARAGE_CATEGORIES = [
  "Pneumatiques",
  "Vitrage",
  "Entretien",
  "Batterie",
  "Distribution",
  "Freinage",
  "Carrosserie",
  "Climatisation",
];

async function populateFicheSelect() {
  const select = document.getElementById("v-ficheId");
  const fiches = await Store.listFiches();
  select.innerHTML =
    `<option value="">— Association automatique par nom de client —</option>` +
    fiches.map((f) => `<option value="${f.id}">${escapeHtml(f.client)}</option>`).join("");
}

async function renderVehicleList(filter = "") {
  const grid = document.getElementById("vehicleGrid");
  const list = await Store.listVehicles();
  const norm = filter.trim().toLowerCase();

  const filtered = norm
    ? list.filter((v) => [v.plate, v.client, v.brand, v.model, v.renter].join(" ").toLowerCase().includes(norm))
    : list;

  grid.innerHTML = filtered.length
    ? filtered
        .map(
          (v) => `
    <div class="agreement-card">
      <div class="agreement-card-header">
        <div>
          <div class="agreement-card-title">${escapeHtml(v.plate)}</div>
          <div class="agreement-card-cat">${escapeHtml([v.brand, v.model].filter(Boolean).join(" ") || "—")}</div>
        </div>
        <span class="pill">${escapeHtml(v.renter || "—")}</span>
      </div>
      <div class="agreement-card-discount" style="color:var(--text); font-size:12.5px; font-weight:600;">${escapeHtml(v.client || "—")}</div>
      <div class="agreement-card-dates">${v.center ? `Centre : ${escapeHtml(v.center)}` : ""}</div>
      <div class="agreement-card-actions">
        <button class="btn btn-ghost" data-action="edit-vehicle" data-id="${v.id}">✎ Modifier</button>
        <button class="btn btn-danger-ghost" data-action="delete-vehicle" data-id="${v.id}">🗑 Supprimer</button>
      </div>
    </div>`
        )
        .join("")
    : `<div class="empty-hint">Aucun véhicule ${norm ? "ne correspond à ce filtre" : "enregistré pour le moment"}.<br/>Cliquez sur « Ajouter un véhicule » pour commencer.</div>`;

  grid.querySelectorAll("[data-action]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.id;
      if (btn.dataset.action === "edit-vehicle") {
        const vehicle = await Store.getVehicle(id);
        await fillVehicleForm(vehicle);
        showTab("vehicleForm");
      } else if (btn.dataset.action === "delete-vehicle") {
        if (confirm("Supprimer définitivement ce véhicule ?")) {
          await Store.deleteVehicle(id);
          await renderVehicleList(document.getElementById("vehicleFilterInput").value);
          await refreshSideStats();
        }
      }
    });
  });
}

document.getElementById("vehicleFilterInput").addEventListener("input", (e) => renderVehicleList(e.target.value));

async function resetVehicleForm() {
  document.getElementById("vehicleFormTitle").textContent = "Ajouter un véhicule";
  document.getElementById("vehicleForm").reset();
  document.getElementById("v-id").value = "";
  await populateFicheSelect();
}

async function fillVehicleForm(v) {
  await populateFicheSelect();
  document.getElementById("vehicleFormTitle").textContent = `Modifier « ${v.plate} »`;
  document.getElementById("v-id").value = v.id;
  document.getElementById("v-plate").value = v.plate || "";
  document.getElementById("v-client").value = v.client || "";
  document.getElementById("v-company").value = v.company || "";
  document.getElementById("v-brand").value = v.brand || "";
  document.getElementById("v-model").value = v.model || "";
  document.getElementById("v-vin").value = v.vin || "";
  document.getElementById("v-year").value = v.year || "";
  document.getElementById("v-engine").value = v.engine || "";
  document.getElementById("v-mileage").value = v.mileage ?? "";
  document.getElementById("v-renter").value = v.renter || "";
  document.getElementById("v-center").value = v.center || "";
  document.getElementById("v-driver").value = v.driver || "";
  document.getElementById("v-ficheId").value = v.ficheId || "";
  document.getElementById("v-contractRef").value = v.contractRef || "";
  document.getElementById("v-contractPath").value = v.contractPath || "";
  document.getElementById("v-allowedProviders").value = (v.allowedProviders || []).join(", ");
  document.getElementById("v-history").value = v.history || "";
}

document.getElementById("cancelVehicleFormBtn").addEventListener("click", () => showTab("vehicles"));

document.getElementById("vehicleForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const vehicle = {
    id: document.getElementById("v-id").value || undefined,
    plate: document.getElementById("v-plate").value.trim().toUpperCase(),
    client: document.getElementById("v-client").value.trim(),
    company: document.getElementById("v-company").value.trim(),
    brand: document.getElementById("v-brand").value.trim(),
    model: document.getElementById("v-model").value.trim(),
    vin: document.getElementById("v-vin").value.trim(),
    year: document.getElementById("v-year").value ? Number(document.getElementById("v-year").value) : null,
    engine: document.getElementById("v-engine").value.trim(),
    mileage: document.getElementById("v-mileage").value ? Number(document.getElementById("v-mileage").value) : null,
    renter: document.getElementById("v-renter").value.trim(),
    center: document.getElementById("v-center").value.trim(),
    driver: document.getElementById("v-driver").value.trim(),
    ficheId: document.getElementById("v-ficheId").value || null,
    contractRef: document.getElementById("v-contractRef").value.trim(),
    contractPath: document.getElementById("v-contractPath").value.trim(),
    allowedProviders: parseListField(document.getElementById("v-allowedProviders").value),
    history: document.getElementById("v-history").value.trim(),
  };
  await Store.saveVehicle(vehicle);
  await renderVehicleList(document.getElementById("vehicleFilterInput").value);
  await refreshSideStats();
  showTab("vehicles");
});

// ============================================================
// FICHES D'EXPLOITATION CLIENTS
// ============================================================
async function populateGarageGrid(selected = {}) {
  const agreements = await Store.listAgreements();
  const grid = document.getElementById("ficheGarageGrid");
  const options = (currentId) =>
    `<option value="">— Auto (moteur de recherche) —</option>` +
    agreements
      .map((a) => `<option value="${a.id}" ${a.id === currentId ? "selected" : ""}>${escapeHtml(a.provider)} (${escapeHtml(a.category || "")})</option>`)
      .join("");
  grid.innerHTML = GARAGE_CATEGORIES.map((cat) => {
    const entry = selected[cat];
    const currentId = typeof entry === "string" ? entry : entry?.agreementId;
    const isExclusive = typeof entry === "object" && !!entry?.exclusive;
    return `
    <div>
      <label>${escapeHtml(cat)}</label>
      <select data-garage-category="${escapeHtml(cat)}">${options(currentId)}</select>
      <label style="display:flex; align-items:center; gap:6px; margin-top:4px; font-size:11.5px; font-weight:400; color:var(--text-dim);">
        <input type="checkbox" data-garage-exclusive="${escapeHtml(cat)}" style="width:auto;" ${isExclusive ? "checked" : ""} />
        Obligatoire (aucune alternative)
      </label>
    </div>`;
  }).join("");
}

function readGarageGrid() {
  const out = {};
  document.querySelectorAll("[data-garage-category]").forEach((sel) => {
    if (!sel.value) return;
    const cat = sel.dataset.garageCategory;
    const exclusiveBox = document.querySelector(`[data-garage-exclusive="${CSS.escape(cat)}"]`);
    out[cat] = { agreementId: sel.value, exclusive: !!exclusiveBox?.checked };
  });
  return out;
}

function parseContacts(text) {
  return (text || "")
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const idx = line.indexOf(":");
      return idx >= 0
        ? { label: line.slice(0, idx).trim(), value: line.slice(idx + 1).trim() }
        : { label: line, value: "" };
    });
}

function formatContacts(contacts) {
  return (contacts || []).map((c) => `${c.label}: ${c.value}`).join("\n");
}

async function renderFicheList(filter = "") {
  const grid = document.getElementById("ficheGrid");
  const list = await Store.listFiches();
  const norm = filter.trim().toLowerCase();
  const filtered = norm ? list.filter((f) => (f.client || "").toLowerCase().includes(norm)) : list;

  grid.innerHTML = filtered.length
    ? filtered
        .map(
          (f) => `
    <div class="agreement-card">
      <div class="agreement-card-header">
        <div>
          <div class="agreement-card-title">${escapeHtml(f.client)}</div>
          <div class="agreement-card-cat">${f.plafond ? `Plafond : ${escapeHtml(String(f.plafond))} € HT` : "Plafond non renseigné"}</div>
        </div>
        ${f.validateurNom ? `<span class="pill">${escapeHtml(f.validateurNom)}</span>` : ""}
      </div>
      <div class="agreement-card-actions">
        <button class="btn btn-ghost" data-action="edit-fiche" data-id="${f.id}">✎ Modifier</button>
        <button class="btn btn-danger-ghost" data-action="delete-fiche" data-id="${f.id}">🗑 Supprimer</button>
      </div>
    </div>`
        )
        .join("")
    : `<div class="empty-hint">Aucune fiche ${norm ? "ne correspond à ce filtre" : "enregistrée pour le moment"}.<br/>Cliquez sur « Ajouter une fiche » pour commencer.</div>`;

  grid.querySelectorAll("[data-action]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.id;
      if (btn.dataset.action === "edit-fiche") {
        const fiche = await Store.getFiche(id);
        await fillFicheForm(fiche);
        showTab("ficheForm");
      } else if (btn.dataset.action === "delete-fiche") {
        if (confirm("Supprimer définitivement cette fiche client ?")) {
          await Store.deleteFiche(id);
          await renderFicheList(document.getElementById("ficheFilterInput").value);
          await refreshSideStats();
        }
      }
    });
  });
}

document.getElementById("ficheFilterInput").addEventListener("input", (e) => renderFicheList(e.target.value));

async function resetFicheForm() {
  document.getElementById("ficheFormTitle").textContent = "Ajouter une fiche client";
  document.getElementById("ficheForm").reset();
  document.getElementById("fi-id").value = "";
  await populateGarageGrid({});
}

async function fillFicheForm(f) {
  document.getElementById("ficheFormTitle").textContent = `Modifier « ${f.client} »`;
  document.getElementById("fi-id").value = f.id;
  document.getElementById("fi-client").value = f.client || "";
  document.getElementById("fi-plafond").value = f.plafond ?? "";
  document.getElementById("fi-validateurNom").value = f.validateurNom || "";
  document.getElementById("fi-validateurCanal").value = f.validateurCanal || "";
  await populateGarageGrid(f.garages || {});
  document.getElementById("fi-ctCentre").value = f.controleTechnique?.centre || "";
  document.getElementById("fi-ctFrequence").value = f.controleTechnique?.frequence || "";
  document.getElementById("fi-ctNotes").value = f.controleTechnique?.notes || "";
  document.getElementById("fi-assistTel").value = f.assistance?.telephone || "";
  document.getElementById("fi-assistNotes").value = f.assistance?.notes || "";
  document.getElementById("fi-relaisAutorise").value = f.vehiculeRelais ? (f.vehiculeRelais.autorise ? "oui" : "non") : "";
  document.getElementById("fi-relaisNotes").value = f.vehiculeRelais?.notes || "";
  document.getElementById("fi-garantieNotes").value = f.garantie?.notes || "";
  document.getElementById("fi-factDest").value = f.facturation?.destinataire || "";
  document.getElementById("fi-factEmail").value = f.facturation?.email || "";
  document.getElementById("fi-factNotes").value = f.facturation?.notes || "";
  document.getElementById("fi-assurCompagnie").value = f.assurance?.compagnie || "";
  document.getElementById("fi-assurTel").value = f.assurance?.telephone || "";
  document.getElementById("fi-assurNotes").value = f.assurance?.notes || "";
  document.getElementById("fi-carburantNotes").value = f.cartesCarburant?.notes || "";
  document.getElementById("fi-peagesNotes").value = f.peages?.notes || "";
  document.getElementById("fi-reglesNotes").value = f.reglesParticulieres?.notes || "";
  document.getElementById("fi-contacts").value = formatContacts(f.contacts);
}

document.getElementById("cancelFicheFormBtn").addEventListener("click", () => showTab("fiches"));

document.getElementById("ficheForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const relaisValue = document.getElementById("fi-relaisAutorise").value;
  const fiche = {
    id: document.getElementById("fi-id").value || undefined,
    client: document.getElementById("fi-client").value.trim(),
    plafond: document.getElementById("fi-plafond").value ? Number(document.getElementById("fi-plafond").value) : null,
    validateurNom: document.getElementById("fi-validateurNom").value.trim(),
    validateurCanal: document.getElementById("fi-validateurCanal").value.trim(),
    garages: readGarageGrid(),
    controleTechnique: {
      centre: document.getElementById("fi-ctCentre").value.trim(),
      frequence: document.getElementById("fi-ctFrequence").value.trim(),
      notes: document.getElementById("fi-ctNotes").value.trim(),
    },
    assistance: {
      telephone: document.getElementById("fi-assistTel").value.trim(),
      notes: document.getElementById("fi-assistNotes").value.trim(),
    },
    vehiculeRelais: relaisValue
      ? { autorise: relaisValue === "oui", notes: document.getElementById("fi-relaisNotes").value.trim() }
      : null,
    garantie: { notes: document.getElementById("fi-garantieNotes").value.trim() },
    facturation: {
      destinataire: document.getElementById("fi-factDest").value.trim(),
      email: document.getElementById("fi-factEmail").value.trim(),
      notes: document.getElementById("fi-factNotes").value.trim(),
    },
    assurance: {
      compagnie: document.getElementById("fi-assurCompagnie").value.trim(),
      telephone: document.getElementById("fi-assurTel").value.trim(),
      notes: document.getElementById("fi-assurNotes").value.trim(),
    },
    cartesCarburant: { notes: document.getElementById("fi-carburantNotes").value.trim() },
    peages: { notes: document.getElementById("fi-peagesNotes").value.trim() },
    reglesParticulieres: { notes: document.getElementById("fi-reglesNotes").value.trim() },
    contacts: parseContacts(document.getElementById("fi-contacts").value),
  };
  // On ne garde les sous-objets que s'ils contiennent une information utile,
  // pour que le chat sache dire "non renseigné" plutôt que d'afficher du vide.
  ["controleTechnique", "assistance", "garantie", "facturation", "assurance", "cartesCarburant", "peages", "reglesParticulieres"].forEach((key) => {
    const obj = fiche[key];
    if (obj && !Object.values(obj).some((v) => v)) fiche[key] = null;
  });
  await Store.saveFiche(fiche);
  await renderFicheList(document.getElementById("ficheFilterInput").value);
  await refreshSideStats();
  showTab("fiches");
});

// ============================================================
// IMPORT EN MASSE (copier/coller depuis Excel)
// ============================================================

// Excel colle naturellement en tabulations ; on tolère aussi le point-virgule
// ou la virgule si l'utilisateur a exporté un CSV.
function splitImportLine(line) {
  if (line.includes("\t")) return line.split("\t");
  if (line.includes(";")) return line.split(";");
  return line.split(",");
}

function importRows(text) {
  return text
    .split("\n")
    .map((l) => l.replace(/\r$/, ""))
    .filter((l) => l.trim().length > 0)
    .map(splitImportLine)
    .map((cols) => cols.map((c) => c.trim()));
}

document.getElementById("importVehiclesBtn").addEventListener("click", async () => {
  const raw = document.getElementById("importVehiclesInput").value;
  const rows = importRows(raw);
  const resultEl = document.getElementById("importVehiclesResult");
  if (!rows.length) {
    resultEl.textContent = "Aucune ligne à importer.";
    return;
  }

  const existing = await Store.listVehicles();
  let created = 0;
  let updated = 0;
  const errors = [];

  for (const cols of rows) {
    const [plate, client, company, brand, model, vin, mileage, renter, center, driver, contractRef, contractPath, allowedProviders, history, year, engine] = cols;
    if (!plate || !client) {
      errors.push(`Ligne ignorée (immatriculation ou client manquant) : ${cols.join(" | ")}`);
      continue;
    }
    const match = existing.find((v) => normalizePlate(v.plate) === normalizePlate(plate));
    const vehicle = {
      id: match?.id,
      plate: plate.toUpperCase(),
      client,
      company: company || "",
      brand: brand || "",
      model: model || "",
      vin: vin || "",
      year: year ? Number(year.replace(/[^\d]/g, "")) : null,
      engine: engine || "",
      mileage: mileage ? Number(mileage.replace(/[^\d.]/g, "")) : null,
      renter: renter || "",
      center: center || "",
      driver: driver || "",
      contractRef: contractRef || "",
      contractPath: contractPath || "",
      allowedProviders: parseListField((allowedProviders || "").replace(/;/g, ",")),
      history: history || "",
    };
    await Store.saveVehicle(vehicle);
    if (match) updated++;
    else created++;
  }

  await renderVehicleList(document.getElementById("vehicleFilterInput").value);
  await refreshSideStats();
  resultEl.innerHTML = `✅ ${created} véhicule(s) créé(s), ${updated} mis à jour.` + (errors.length ? `<br/>⚠️ ${errors.length} ligne(s) ignorée(s) : <br/>${errors.map(escapeHtml).join("<br/>")}` : "");
});

document.getElementById("importFichesBtn").addEventListener("click", async () => {
  const raw = document.getElementById("importFichesInput").value;
  const rows = importRows(raw);
  const resultEl = document.getElementById("importFichesResult");
  if (!rows.length) {
    resultEl.textContent = "Aucune ligne à importer.";
    return;
  }

  const existing = await Store.listFiches();
  let created = 0;
  let updated = 0;
  const errors = [];

  for (const cols of rows) {
    const [client, plafond, validateurNom, validateurCanal, assistTel, relais, factDest, factEmail, assurCompagnie, assurTel] = cols;
    if (!client) {
      errors.push(`Ligne ignorée (client manquant) : ${cols.join(" | ")}`);
      continue;
    }
    const match = existing.find((f) => (f.client || "").trim().toLowerCase() === client.trim().toLowerCase());
    const fiche = {
      id: match?.id,
      client,
      plafond: plafond ? Number(plafond.replace(/[^\d.]/g, "")) : null,
      validateurNom: validateurNom || "",
      validateurCanal: validateurCanal || "",
      garages: match?.garages || {},
      assistance: assistTel ? { telephone: assistTel, notes: match?.assistance?.notes || "" } : match?.assistance || null,
      vehiculeRelais: relais ? { autorise: /^oui|o|yes|true$/i.test(relais.trim()), notes: match?.vehiculeRelais?.notes || "" } : match?.vehiculeRelais || null,
      facturation: (factDest || factEmail) ? { destinataire: factDest || "", email: factEmail || "", notes: match?.facturation?.notes || "" } : match?.facturation || null,
      assurance: (assurCompagnie || assurTel) ? { compagnie: assurCompagnie || "", telephone: assurTel || "", notes: match?.assurance?.notes || "" } : match?.assurance || null,
      controleTechnique: match?.controleTechnique || null,
      garantie: match?.garantie || null,
      cartesCarburant: match?.cartesCarburant || null,
      peages: match?.peages || null,
      reglesParticulieres: match?.reglesParticulieres || null,
      contacts: match?.contacts || [],
    };
    await Store.saveFiche(fiche);
    if (match) updated++;
    else created++;
  }

  await renderFicheList(document.getElementById("ficheFilterInput").value);
  await refreshSideStats();
  resultEl.innerHTML = `✅ ${created} fiche(s) créée(s), ${updated} mise(s) à jour.` + (errors.length ? `<br/>⚠️ ${errors.length} ligne(s) ignorée(s) : <br/>${errors.map(escapeHtml).join("<br/>")}` : "");
});

// ============================================================
// RÈGLES DE MARQUE (globales, indépendantes du client)
// ============================================================
async function renderBrandRuleList(filter = "") {
  const grid = document.getElementById("brandRuleGrid");
  const list = await Store.listBrandRules();
  const norm = filter.trim().toLowerCase();
  const filtered = norm ? list.filter((r) => (r.brand || "").toLowerCase().includes(norm)) : list;

  grid.innerHTML = filtered.length
    ? filtered
        .map(
          (r) => `
    <div class="agreement-card">
      <div class="agreement-card-header">
        <div>
          <div class="agreement-card-title">${escapeHtml(r.brand)}</div>
          <div class="agreement-card-cat">${(r.categories || []).length ? escapeHtml(r.categories.join(", ")) : "Toutes catégories"}</div>
        </div>
        ${r.exclusiveOfficialDealer ? `<span class="pill">🔒 Obligatoire</span>` : `<span class="pill">Préférence</span>`}
      </div>
      ${r.notes ? `<div class="agreement-card-dates">${escapeHtml(r.notes)}</div>` : ""}
      <div class="agreement-card-actions">
        <button class="btn btn-ghost" data-action="edit-brandrule" data-id="${r.id}">✎ Modifier</button>
        <button class="btn btn-danger-ghost" data-action="delete-brandrule" data-id="${r.id}">🗑 Supprimer</button>
      </div>
    </div>`
        )
        .join("")
    : `<div class="empty-hint">Aucune règle de marque ${norm ? "ne correspond à ce filtre" : "enregistrée pour le moment"}.<br/>Ex : « Iveco → concessionnaire officiel obligatoire, toutes catégories ».</div>`;

  grid.querySelectorAll("[data-action]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.id;
      if (btn.dataset.action === "edit-brandrule") {
        const rule = await Store.getBrandRule(id);
        fillBrandRuleForm(rule);
        showTab("brandRuleForm");
      } else if (btn.dataset.action === "delete-brandrule") {
        if (confirm("Supprimer définitivement cette règle de marque ?")) {
          await Store.deleteBrandRule(id);
          await renderBrandRuleList(document.getElementById("brandRuleFilterInput").value);
          await refreshSideStats();
        }
      }
    });
  });
}

document.getElementById("brandRuleFilterInput").addEventListener("input", (e) => renderBrandRuleList(e.target.value));

async function resetBrandRuleForm() {
  document.getElementById("brandRuleFormTitle").textContent = "Ajouter une règle de marque";
  document.getElementById("brandRuleForm").reset();
  document.getElementById("br-id").value = "";
}

function fillBrandRuleForm(r) {
  document.getElementById("brandRuleFormTitle").textContent = `Modifier « ${r.brand} »`;
  document.getElementById("br-id").value = r.id;
  document.getElementById("br-brand").value = r.brand || "";
  document.getElementById("br-exclusive").checked = !!r.exclusiveOfficialDealer;
  document.getElementById("br-categories").value = (r.categories || []).join(";");
  document.getElementById("br-notes").value = r.notes || "";
}

document.getElementById("cancelBrandRuleFormBtn").addEventListener("click", () => showTab("brandRules"));

document.getElementById("brandRuleForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const rule = {
    id: document.getElementById("br-id").value || undefined,
    brand: document.getElementById("br-brand").value.trim(),
    exclusiveOfficialDealer: document.getElementById("br-exclusive").checked,
    categories: parseListField(document.getElementById("br-categories").value.replace(/;/g, ",")),
    notes: document.getElementById("br-notes").value.trim(),
  };
  await Store.saveBrandRule(rule);
  await renderBrandRuleList(document.getElementById("brandRuleFilterInput").value);
  await refreshSideStats();
  showTab("brandRules");
});

// ---------------- Paramètres ----------------
async function loadSettings() {
  const settings = await Store.getSettings();
  document.getElementById("s-provider").value = settings.aiProvider || "local";
  document.getElementById("s-apikey").value = settings.openaiApiKey || "";
}

document.getElementById("saveSettingsBtn").addEventListener("click", async () => {
  await Store.saveSettings({
    aiProvider: document.getElementById("s-provider").value,
    openaiApiKey: document.getElementById("s-apikey").value.trim(),
  });
  const btn = document.getElementById("saveSettingsBtn");
  const original = btn.textContent;
  btn.textContent = "✅ Enregistré";
  setTimeout(() => (btn.textContent = original), 1400);
});

// ---------------- Init ----------------
(async function init() {
  await renderList();
  await renderVehicleList();
  await renderFicheList();
  await renderBrandRuleList();
  await refreshSideStats();
  await loadSettings();
})();
