# Assistant Accords Fournisseurs — extension Chrome

Un assistant IA de gestion de flotte : saisissez une immatriculation, et
discutez ensuite en langage naturel comme avec un responsable flotte
expérimenté (garages recommandés, plafonds de validation, assistance,
contrôle technique, contrat, etc.), sans jamais ouvrir un PDF.

## Installation (mode développeur)

1. Ouvrez `chrome://extensions` dans Chrome.
2. Activez le **Mode développeur** (en haut à droite).
3. Cliquez sur **Charger l'extension non empaquetée**.
4. Sélectionnez ce dossier (`extension/`).
5. L'icône apparaît dans la barre d'outils : cliquez dessus pour ouvrir le chat.

Aucune compilation n'est nécessaire : le code est prêt à l'emploi.

### Autoriser l'ouverture des PDF locaux (optionnel)

Le bouton « 📂 Ouvrir le contrat » ouvre le chemin renseigné (ex.
`D:\Contrats\Euromaster.pdf`). Pour que Chrome autorise l'ouverture de
fichiers `file://` depuis l'extension : `chrome://extensions` → carte de
l'extension → **Détails** → activez **Autoriser l'accès aux URL de
fichiers**.

## Module véhicules (nouveau)

- Saisissez une immatriculation (ex. `AA-855-ZA`) dans le chat : la fiche du
  véhicule (client, marque, modèle, loueur…) se charge automatiquement, ainsi
  que la fiche d'exploitation du client si elle existe. Toutes les questions
  suivantes portent automatiquement sur ce véhicule — la barre en haut du
  chat le rappelle, avec un bouton ✕ pour changer de véhicule.
- Questions reconnues sans reformulation : garages recommandés par catégorie
  (pneus, pare-brise, carrosserie, vidange, batterie, distribution, freinage,
  climatisation), plafond de validation, comparaison automatique d'un devis
  chiffré au plafond (« devis de 1 200 € »), contrôle technique, assistance/
  dépannage, véhicule relais, garantie, facturation, assurance, cartes
  carburant, péages, contrat, et « qui appeler » (contacts de la fiche).
- **⚙ Administration → 🚗 Véhicules** : fiche par véhicule (immatriculation,
  client, société, marque/modèle, VIN, kilométrage, loueur, centre,
  conducteur, contrat, prestataires autorisés, historique).
- **⚙ Administration → 🗂 Fiches clients** : plafond, validateur/canal,
  garage préféré par catégorie (ou recherche automatique si non précisé),
  contrôle technique, assistance, véhicule relais, garantie, facturation,
  assurance, cartes carburant, péages, règles particulières, contacts.
- Un véhicule et une fiche de démonstration (`AA-855-ZA` / ABC Transport)
  sont préchargés à l'installation pour tester tout de suite ; supprimez-les
  quand vous ajoutez vos propres véhicules.
- Les accords fournisseurs supportent désormais un téléphone et une adresse,
  ce qui active les boutons 📍 Ouvrir Maps / 📞 Appeler / 📅 Prendre RDV sur
  les cartes de réponse liées à un véhicule.

## Recommandation de garage à proximité (nouveau)

Depuis la carte « 🚗 Véhicule trouvé », un bouton **🔍 Trouver un garage pour
l'entretien** lance une recherche géolocalisée :

1. L'utilisateur indique sa ville, ou autorise la géolocalisation du
   navigateur.
2. L'extension interroge **OpenStreetMap** (Nominatim pour géocoder la
   ville, Overpass API pour lister les garages/concessions à proximité) —
   **gratuit, sans clé API**.
3. Les résultats sont classés par : concession officielle de la marque du
   véhicule > prestataire déjà négocié dans vos accords fournisseurs >
   garage spécialisé dans la marque > concession d'une autre marque >
   garage multimarque, puis par distance.
4. Chaque garage affiche nom, adresse, distance, horaires et marques quand
   OpenStreetMap les renseigne, avec boutons 📞 Appeler / ✉️ E-mail /
   🌐 Site / 🧭 Itinéraire / 📅 Prendre RDV.

**Limite honnête à connaître** : contrairement à Google Places (API
payante), OpenStreetMap ne fournit ni note moyenne/avis clients ni prix
estimatif de révision. Ces deux informations ne sont donc **jamais
inventées** : la note renvoie vers un lien direct « voir sur Google Maps »,
et le prix ne s'affiche que s'il provient d'un vrai accord négocié dans vos
propres données. Si vous voulez des notes/avis réels à terme, il faudra
brancher une clé Google Places API payante (`search.js`/`garagefinder.js`
sont structurés pour accueillir une seconde source sans tout réécrire).

La carte affichée est une carte OpenStreetMap intégrée centrée sur la
position de l'utilisateur (sans épingle par garage, ce qui nécessiterait
Google Maps payant) — le bouton Itinéraire de chaque résultat ouvre la
destination exacte dans Google Maps.

## Prise en main

- À la première installation, des accords fournisseurs réels sont
  préchargés (Euromaster VL/PL, Feu Vert, Profil Plus, Martenat, Ketrucks,
  Norauto). Supprimez-les depuis **⚙ Administration** si besoin.
- **⚙ Administration** (clic sur la roue dentée, ou clic droit sur l'icône →
  Options) : gérez accords, véhicules et fiches clients.
- **Chat** : posez une question comme à un collègue (« Le client veut
  changer ses pneus, où l'envoyer ? », ou une immatriculation). L'assistant
  reconnaît les synonymes métier (pneu/roues/train avant, pare-brise/vitrage/
  impact, vidange/huile, etc.) et les mots-clés propres à chaque accord.
- **▤ Tableau de bord** : nombre d'accords, de prestataires, de catégories,
  et contrats qui expirent sous 30 jours.
- **☆ Favoris** : épinglez les prestataires que vous recommandez le plus.
- **↺ Historique** : les questions posées sont conservées localement,
  supprimables en un clic.
- Une notification Chrome native prévient automatiquement quand un contrat
  arrive à expiration dans moins de 30 jours.

Toutes les données restent **en local** sur le poste, via `chrome.storage.local`
— rien n'est envoyé sur un serveur externe par défaut.

## Compréhension du langage naturel

Le moteur (`search.js`) ne fait pas une simple recherche de mot-clé : il
normalise la question (accents, casse), l'étend via un dictionnaire de
synonymes métier (pneus, pare-brise, vidange, batterie, distribution, freins,
carrosserie, climatisation…), puis note chaque accord actif selon le nombre
de correspondances, la priorité définie par l'administrateur et le statut
épinglé. Il reconnaît aussi les tournures directes (« quelle remise chez
Feu Vert ? ») et les cas où le prestataire cité n'a aucun accord enregistré,
en proposant alors l'alternative recommandée.

Le même moteur détecte une immatriculation n'importe où dans le message
(formats SIV `AA-123-AA` et FNI `123 ABC 75`), garde le véhicule sélectionné
en mémoire de conversation, puis route chaque question vers l'intention
métier correspondante (garage par catégorie, plafond, devis à comparer,
contrôle technique, assistance…) avant de retomber, si rien ne correspond,
sur la recherche générique d'accords fournisseurs.

Dans **⚙ Paramètres IA**, vous pouvez basculer sur un moteur OpenAI si vous
souhaitez une compréhension encore plus fine des formulations très libres —
le moteur local reste le réglage par défaut et ne fait fuiter aucune donnée.

## Un mot sur les choix techniques

Le brief initial mentionnait React/TypeScript/Vite/Fuse.js. Cet
environnement de génération n'a pas d'accès réseau pour lancer `npm install`
ou un bundler, donc j'ai livré l'équivalent fonctionnel en **JavaScript
vanilla, HTML et CSS**, organisé en couches claires (`storage.js` = modèle,
`search.js` = logique métier, `popup.js`/`admin.js` = contrôleur/vue) —
c'est aussi ce qui vous permet de charger l'extension telle quelle, sans
étape de build à maintenir. Si vous voulez migrer vers React + Vite plus
tard (par exemple pour une UI plus riche), la séparation des fichiers rend
la bascule directe : chaque fichier `.js` peut devenir un module TypeScript
sans changer la logique.

Fichiers du projet :

```
manifest.json        Déclaration de l'extension (Manifest V3)
storage.js            Accès aux données (chrome.storage.local) : accords,
                       véhicules, fiches clients, historique, paramètres
search.js             Moteur de compréhension d'intention + synonymes +
                       détection d'immatriculation + intentions véhicule
background.js         Service worker : alarme + notifications d'expiration,
                       données de démonstration (accords, véhicule, fiche)
popup.html/.css/.js   Le chat (vue par défaut de l'extension) + barre
                       véhicule sélectionné
admin.html/.css/.js   L'administration (CRUD accords / véhicules / fiches
                       clients, paramètres)
styles.css            Design system partagé (tokens, composants)
icons/                Icônes 16/48/128 px
```
