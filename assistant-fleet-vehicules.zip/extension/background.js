/**
 * background.js
 * Service worker MV3 : planifie une vérification quotidienne des contrats
 * qui arrivent à expiration dans moins de 30 jours et affiche une
 * notification système native Chrome.
 */
importScripts("storage.js");

const ALARM_NAME = "check-expiring-agreements";

chrome.runtime.onInstalled.addListener(async () => {
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: 60 * 12 }); // 2x/jour
  await seedSampleDataIfEmpty();
  await seedVehicleDemoIfEmpty();
  checkExpiringAgreements();
});

// Accords préchargés à la première installation, à partir des conditions
// commerciales réellement négociées (dossier PILOOTE : Euromaster, Feu Vert,
// Profil Plus, Martenat, Ketrucks, Norauto). N'écrase jamais des données
// existantes — si vous avez déjà vos propres accords, rien n'est modifié.
async function seedSampleDataIfEmpty() {
  const existing = await Store.listAgreements();
  if (existing.length > 0) return;

  const samples = [
    {
      provider: "Euromaster (Véhicules Légers)",
      category: "Pneumatiques & entretien VL/VUL/4x4",
      keywords: [
        "pneu", "pneus", "pneumatique", "tourisme", "camionnette", "4x4", "vul",
        "michelin", "continental", "hankook", "kleber", "falken", "tigar", "bridgestone",
        "goodyear", "pirelli", "dunlop", "uniroyal", "bfgoodrich", "firestone", "tracmax",
        "montage", "demontage", "equilibrage", "permutation", "retour sur jante",
        "geometrie", "parallelisme", "reparation", "atelier mobile",
        "frein", "freinage", "plaquette", "disque", "amortisseur", "direction", "suspension",
        "batterie", "lampe", "ampoule", "distribution", "courroie de distribution",
        "vidange", "revision", "entretien", "huile",
        "climatisation", "clim", "liquide de refroidissement",
        "pare-brise", "parebrise", "vitrage", "essuie-glace", "balai", "controle technique"
      ],
      discount:
        "PNEUS TOURISME/CAMIONNETTE/4X4 (remise sur Barème Fournisseur) :\nMICHELIN 31% | CONTINENTAL 35% | HANKOOK 32% | KLEBER 21% | FALKEN 32% | TIGAR 17% | BRIDGESTONE 33% | GOODYEAR 24% | PIRELLI 20% | DUNLOP 18% | UNIROYAL 26% | BFGOODRICH 21% | FIRESTONE 0% | TRACMAX 47% | EVERGREEN 48% | BLACK STAR 10% | LEONARD 39%\n\nPRESTATIONS & PIÈCES D'ENTRETIEN COURANT (20% chacune) :\nMontage/Démontage | Équilibrage | Permutation/Retour sur jante | Déplacement site (atelier mobile) | Géométrie | Réparation | Freinage (pièces) | Amortisseurs (pièces) | Pièces de direction & suspension (pièces) | Batteries (pièces) | Lampes (pièces) | Courroie de distribution (pièces) | Forfait Vidange/Révision | Forfait Climatisation | Forfait Liquide de refroidissement | Forfait Réparation de pare-brise | Forfait Balais Essuie-Glaces | Forfait Contrôle Technique",
      conditions:
        "Conditions commerciales Pneus et Prestations Véhicules Légers au 17-01-2024.\nLes remises sur les pneus s'appliquent sur le Barème de Facturation en vigueur en date de l'achat.\nLes remises sur les prestations s'appliquent sur le tarif Euromaster en vigueur en date de l'achat.\nTarifs modifiables sans préavis en cas d'évolution des barèmes fournisseurs.",
      brands: ["Michelin", "Continental", "Hankook", "Kleber", "Falken", "Tigar", "Bridgestone", "Goodyear", "Pirelli", "Dunlop", "Uniroyal", "BFGoodrich", "Firestone", "Tracmax", "Evergreen", "Black Star", "Leonard"],
      services: ["Montage", "Équilibrage", "Géométrie", "Réparation", "Freinage", "Batteries", "Distribution", "Vidange", "Climatisation", "Pare-brise"],
      comments: "Contact commercial : Julien Clolus (Euromaster).",
      pdfPath: "D:\\Contrats\\EUROMASTER\\VL\\CONDITIONS COMMERCIALES PILOOTE_202401.pdf",
      priority: 9,
      pinned: false,
    },
    {
      provider: "Euromaster (Poids Lourds)",
      category: "Pneumatiques & entretien Poids Lourd",
      keywords: [
        "poids lourd", "pl", "camion", "remorque", "autocar",
        "pneu pl", "pneus pl", "michelin", "goodyear", "dunlop", "continental",
        "bridgestone", "firestone", "bfgoodrich", "hankook", "rechape", "recreusage",
        "montage", "demontage", "equilibrage", "permutation", "retour sur jante",
        "geometrie pl", "atelier mobile", "depannage", "assistance",
        "tachygraphe", "ethylotest", "limiteur de vitesse",
        "climatisation pl", "inspection", "gestion de parc"
      ],
      discount:
        "PNEUS PL NEUFS (remise sur BF) :\nMICHELIN 44% | GOODYEAR 19% | DUNLOP 19% | CONTINENTAL 36% | BRIDGESTONE 46% | FIRESTONE 46% | BFGOODRICH 56% | HANKOOK 46%\n\nPNEUS PL RECHAPÉS (remise sur BF) :\nMICHELIN REMIX 14% | LAURENT 10% | NEXT TREAD 15% | TREADMAX 15% | CONTINENTAL CONTIRE 28% | BRIDGESTONE 30% | ALPHATREAD 38% | BANDAG 25%\n\nPRESTATIONS PL (10% chacune) :\nMontage/Démontage | Pose/Dépose | Équilibrage | Permutation/Retour sur jante | Recreusage | Pression | Réparation | Autres prestations PL (hors inspections, dépannage, déplacements, tachy, éthylo, géométrie) | Déplacement atelier mobile | Dépannage",
      conditions:
        "Conditions commerciales Pneus et Prestations Véhicules Industriels au 04-11-2024.\nAssistance dépannage PL 24/7 : 0820 90 40 40.\nTarifs susceptibles de variation en cours d'année selon évolution des barèmes fournisseurs.",
      brands: ["Michelin", "Goodyear", "Dunlop", "Continental", "Bridgestone", "Firestone", "BFGoodrich", "Hankook", "Laurent", "Next Tread", "Treadmax", "Alphatread", "Bandag"],
      services: ["Montage PL", "Équilibrage PL", "Dépannage PL", "Géométrie PL", "Tachygraphie"],
      comments: "Contact commercial : Julien Clolus (Euromaster).",
      pdfPath: "D:\\Contrats\\EUROMASTER\\PL\\C-10973_1730717453510.pdf",
      priority: 7,
      pinned: false,
    },
    {
      provider: "Feu Vert",
      category: "Pneumatiques & entretien",
      keywords: [
        "pneu", "pneus", "tourisme", "vul", "4x4",
        "michelin", "continental", "hankook", "pirelli", "dunlop", "goodyear", "bridgestone",
        "nokian", "nexen", "kleber", "uniroyal", "firestone", "rovelo", "tracmax",
        "jante", "valve", "frein", "freinage", "plaquette", "disque",
        "balai essuie-glace", "batterie", "eclairage", "electricite",
        "transmission", "direction", "amortisseur", "embrayage", "echappement",
        "distribution", "pare-brise", "parebrise", "vitrage", "vitre",
        "fluide", "liquide", "adblue", "lubrifiant", "filtration", "huile",
        "climatisation", "clim", "revision", "vidange", "bougie", "geometrie", "parallelisme"
      ],
      discount:
        "PNEUS Marques Premium/Médium (remise sur Barème Fournisseur) :\nMichelin 30% | Continental 38% | Hankook 30% | Pirelli 46% | Dunlop 36% | Goodyear 36% | Bridgestone 32% | Nokian 25% | Nexen 36% | Kleber 28% | Uniroyal 28% | Firestone 22%\n\nPNEUS Marques Budget (Tarif National) :\nFeu Vert 5% | Rovelo 5% | Tracmax 5%\n\nPIÈCES D'USURE :\nJantes et Valves 5% | Freinage 15% | Balais essuie-glace 15% | Batterie/Éclairage/Électricité 15% | Transmission/Direction 15% | Amortisseurs 15% | Embrayage 15% | Échappement 15% | Distribution 15% | Vitrages (pare-brise) 15%\n\nPRODUITS D'ENTRETIEN :\nFluides/Liquides/AD Blue 15% | Lubrifiant et Filtration 15%\n\nACCESSOIRES & ÉQUIPEMENTS :\nSon et Navigation : prix nets Feu Vert | Équipements/Accessoires Hiver 5% | Vélo et Accessoires 2 Roues : non proposé\n\nPRESTATIONS ET SERVICES :\nForfaits et Main d'œuvre pneus 15% | Forfaits Révisions 15% | Forfaits Bougies 15% | Forfaits Freinage 15% | Forfaits Climatisation 15% | Forfaits Distribution 15% | Autres Forfaits et Main d'œuvre 15% | Gardiennage de pneus et roues : voir tarif | Services mobilité : voir tarif | Contrôle Technique : non proposé | Vitrage : prix nets",
      conditions:
        "Accord Feu Vert Entreprises — Offre Full Piloote.\nBase tarifaire pneus : Barème Fournisseur (marques Premium/Médium) ou Tarif National standard (marques Budget).\nBase tarifaire prestations : Tarif Feu Vert Entreprises.\nPneus hiver et 4 saisons autorisés.",
      brands: ["Michelin", "Continental", "Hankook", "Pirelli", "Dunlop", "Goodyear", "Bridgestone", "Nokian", "Nexen", "Kleber", "Uniroyal", "Firestone", "Feu Vert", "Rovelo", "Tracmax"],
      services: ["Montage pneu", "Réparation pneu", "Géométrie", "Freinage", "Climatisation", "Distribution", "Vitrage"],
      comments: "Contact : feuvert-entreprises@feuvert.fr.",
      pdfPath: "D:\\Contrats\\FEU VERT\\Offre Pneus & Entretien Piloote_20240128.pdf",
      priority: 6,
      pinned: false,
    },
    {
      provider: "Profil Plus (Véhicules Légers)",
      category: "Pneumatiques Tourisme/Camionnette/4x4",
      keywords: [
        "pneu", "pneus", "tourisme", "camionnette", "4x4",
        "michelin", "hankook", "goodyear", "bridgestone", "firestone", "kleber"
      ],
      discount:
        "PNEUS TOURISME/CAMIONNETTE/4X4, remise sur Barème Fournisseur selon diamètre (≤16\" / >16\") :\nMichelin 32%/34% | Hankook 31%/36% | Goodyear 40%/42% | Bridgestone 44%/46% | Firestone 36%/36% | Kleber 24%/27%",
      conditions:
        "Tarif Profil Plus (réseau national de spécialistes pneumatiques indépendants).\nDétail des prestations (montage, géométrie, pack mobilité) disponible dans le tarif joint.",
      brands: ["Michelin", "Hankook", "Goodyear", "Bridgestone", "Firestone", "Kleber"],
      services: ["Montage", "Géométrie", "Pack mobilité"],
      comments: "",
      pdfPath: "D:\\Contrats\\PROFILPLUS\\VL\\Tarification_ProfilPlus_2024.pdf",
      priority: 5,
      pinned: false,
    },
    {
      provider: "Profil Plus (Poids Lourds)",
      category: "Pneumatiques Poids Lourd",
      keywords: [
        "poids lourd", "pl", "camion",
        "michelin", "hankook", "bridgestone", "firestone", "continental", "giti", "dpi",
        "rechape", "laurent", "abr", "montage", "demontage", "permutation", "retour sur jante", "equilibrage"
      ],
      discount:
        "PNEUS PL NEUFS (remise sur BF) :\nMichelin 44% | Hankook 46% | Bridgestone 45% | Firestone 42% | Continental 35% | Giti (DPI) 26%\n\nPNEUS PL RECHAPÉS (remise sur BF) :\nMichelin 14% | Laurent/TD 29% | ABR 22%",
      conditions:
        "Barème Prestations Industrielles Profil Plus 2023/2024.\nTarif au 1er décembre 2023 pour les prestations (montage/démontage, permutation, retour sur jante, équilibrage).",
      brands: ["Michelin", "Hankook", "Bridgestone", "Firestone", "Continental", "Giti"],
      services: ["Montage PL", "Démontage PL", "Équilibrage PL"],
      comments: "",
      pdfPath: "D:\\Contrats\\PROFILPLUS\\PL\\Profil Plus - Traifs Prestations industrielles.pdf",
      priority: 5,
      pinned: false,
    },
    {
      provider: "Martenat (MSB Martenat Sud Bretagne — Iveco)",
      category: "Pièces détachées & main d'œuvre Poids Lourd (Iveco)",
      keywords: [
        "iveco", "daily", "poids lourd", "pl", "camping-car", "fiat pro", "remorque",
        "filtre", "filtre a air", "filtre a huile", "filtre a combustible", "filtre dessicateur",
        "embrayage", "disque de frein", "plaquette de frein", "tambour de frein", "machoire",
        "amortisseur", "balai essuie-glace", "retroviseur", "pare-brise", "parebrise",
        "demarreur", "alternateur", "radiateur", "batterie", "liquide de refroidissement",
        "depannage", "main d'oeuvre", "mo", "diagnostic"
      ],
      discount:
        "RÉGIME DE REMISE PAR FAMILLE DE PIÈCES (code Martenat) :\nPièces d'entretien courant P 40\nFiltres à air P 40\nFiltres à huile P 40\nFiltres à combustible P 40\nFiltres dessicateurs P 40\nFiltres spécifiques P 40\nPièces d'usure P 40\nEmbrayage P 40\nDisques et plaquettes de frein P 40\nTémoins d'usure de frein S1 15\nTambours de frein P 40\nMâchoires et garnitures de frein P 40\nCylindres pneumatiques ES P 40\nPlateaux de frein Daily P 40\nAmortisseurs chassis&cabine P 40\nBalais essuie-glace P 40\nMaintenance P41 40\nRétroviseurs P 40\nPare-brises P 40\nDémarreurs&Alternateurs ES P41 40\nDémarreurs&Alternateurs P1 40\nJoints pare-brises R 20\nFeux&Cabochons AR P41 40\nEquipement moteur Q 40\nRadiateurs&Ventilateurs Q 40\nRadiateurs&Ventilateurs ES Q 40\nCulasses&Turbos ES Q 40\nEquipement appareil pneumatique Q 40\nPièces de rechange divers Q 40\nFiltration BV&Direction Q 40\nProjecteurs Q 40\nMécanique courante R 20\nElectricité courante R 20\nCarrosserie courante R 20\nPare-chocs AR tôle R1 20\nPare-chocs AR plastique R1 20\nTôlerie diverse R 20\nJoint de pare-brise R 20\nMécanique diverse S 15\nElectricité diverse S 15\nTémoins de freins S1 15\nEquipement de cabine divers S 15\nAccessoires boutique T 10\nProduits peinture T 10\nBatteries T 10\nRadios&Antennes T 10\nLiquide de refroidissement T 10\nPièces à faible rotation T 10\nGrande pièce de tôlerie T1 10\nPièces à composants électriques T 10\nGros organes neufs et ES U 8\nDivers pièces mécaniques U 8\nDivers équipements de cabine U 8\nChassis, ponts, essieux V 8\nSous organes principaux V 8\nOutils et documentations V 8\nPièces à prix nets 0\n\nMAIN D'ŒUVRE : 89€/h (<5T) | 96€/h (>5T) | 99€/h (camping-car intégral) | 89€/h (Fiat Pro) | 89€/h (remorque).\nDÉPANNAGE : Forfait PEC dépannage VUL 91€ | Forfait PEC dépannage VI 182€ | Frais de dossier IVECO 24/24 : 102€ | Forfait km dépannage : 4€ | Diag station easy : 59€.",
      conditions:
        "Société : MSB Martenat Sud Bretagne, dépôt Quimper.\nGrille de remise par code famille de pièces (P/Q/R/S/T/U/V selon la catégorie).",
      brands: ["Iveco"],
      services: ["Main d'œuvre atelier", "Dépannage", "Diagnostic"],
      comments: "Concessionnaire Iveco.",
      pdfPath: "D:\\Contrats\\MARTENAT\\SMartenat S23101315140.pdf",
      priority: 6,
      pinned: false,
    },
    {
      provider: "Ketrucks (Renault Trucks)",
      category: "Pièces détachées Poids Lourd (Renault Trucks)",
      keywords: [
        "renault trucks", "poids lourd", "pl", "camion", "dxi", "dci", "euro 6",
        "frein", "freinage", "disque de frein", "plaquette de frein", "garniture de frein",
        "embrayage", "amortisseur", "pare-brise", "parebrise", "courroie", "distribution",
        "filtre a air", "filtre a gasoil", "filtre a huile", "batterie", "radiateur",
        "alternateur", "demarreur", "injecteur", "roulement", "eclairage", "ampoule"
      ],
      discount:
        "GRILLE DE REMISE PAR FAMILLE DE PIÈCES (Grille N°635, remise sur Barème Fournisseur) :\n\nVEHICULE UTILITAIRE:\n101 BV & TRANS ES 5% | 102 MOTEUR ES 5% | 103 MOT E/S MASCOT 0% | 104 DIRECT. ES 5% | 105 REPRISE E/S 0% | 106 BV DIR 0% | 107 ELECTRONIQUE ES 5% | 108 TURBOS ES 5% | 109 ARBRE TRANS ES 5% | 110 VALUE MAINTENAN 5% | 111 DIVERS 2 0% | 112 DIVERS 3 0% | 113 ORGAN E TECH ES 0% | 114 POT CATALYTI ES 5% | 115 DIVERS 6 5% | 116 ORGANES E TECH 0% | 117 ELECTRONIQUE 5% | 118 DIVERS -% | 119 POST TRAITEMENT 5% | 120 PR INJ 5% | 121 CHAS/LIAIS.SOL 5% | 122 PR MOTEUR 5% | 123 PR BV 5% | 124 PR CHASSIS 0% | 125 PR FREINAGE 5% | 126 PR CARROSSERIE 5% | 127 PR ELECT 5% | 128 PR CARROSS 0% | 129 EQPT SPEC 5% | 131 ORG LIAIS SOL 5% | 132 MOTEUR 5% | 133 BV&TRANSMISSION 5% | 134 MOT MASCOTT 0% | 135 BV MASCOTT 0% | 136 CAB 5% | 137 BATTERIES ZE 5% | 138 TURBO NEUF 5% | 139 COMPR CLIM ES 5% | 140 RES GO 15% | 141 KIT EMB NEUF 15% | 142 PR MOT 5% | 143 KIT FREIN DISQU 0% | 144 PIECES DIVERS -% | 145 CART AIR 20% | 146 CART GO 20% | 147 CART HUILE 20% | 148 JOINT 5% | 149 INJ NEUF 5% | 150 EMBRAYAGE NEUF 15% | 151 KITS EMB ES 15% | 152 DISQUE FREIN 20% | 153 PCES DIRECTION 15% | 154 EQPT ES FREIN 15% | 155 INJECT ES 15% | 156 RLT 15% | 157 ALT DEM ES 15% | 158 EQUIPEMENTS ES 15% | 159 RADIATEURS ES 20% | 160 VASE EXPANSION 20% | 161 LAME RESS 15% | 162 DIVERS 8 5% | 163 BATTERIE 20% | 164 GARN FREIN 20% | 165 PLAQUETTE FREIN 20% | 166 KIT FREIN 15% | 167 FLEXIBLE 5% | 168 AMORTISSEUR 15% | 169 DIVERS -% | 170 BEG 20% | 171 APP CONT 5% | 172 COMPOSANT ELECT 5% | 173 ALT DEM NEUF 5% | 174 DIVERS -% | 175 ECLAIRAGE 15% | 176 SIGNALISATION 15% | 177 AMPOULE 20% | 178 DIVERS -% | 179 DIVERS -% | 180 PARE BRISE 15% | 181 COURROIE 15% | 182 BAVETTE 15% | 183 RETRO 15% | 184 PROD SEMI STD 5% | 185 KIT FILTR 20% | 186 RADIA NEUF 15% | 187 FLEXIBLE 15% | 188 ECHPT 15% | 189 POT CATALYTIQUE 5% | 190 PR CARROSSERIE 5% | 191 PR CARROSSERIE 5% | 192 DIVERS -% | 193 OPTIMISATION 5% | 194 DIVERS STATION 5% | 195 SECURITE 15% | 196 VIE A BORD 5% | 197 PERSONALISATION 5% | 198 DIVERS -% | 199 DIVERS -%\n\nMOTEURS dCi-Dxi:\n301 BV & TRANS ES 5% | 302 MOT COMPLET ES 5% | 303 GROUPES EMBIELL 5% | 304 DIRECTION ES 5% | 305 VALEUR REPRISE 0% | 306 ORG E/S SUR DDE 0% | 307 FACTURATION 0% | 308 TURBOS ES 5% | 309 ECHANGES STANDA 0% | 310 DOCUMENTATION 0% | 311 OBJETS PUBLICIT 0% | 312 OUTILLAGE SPECI 0% | 313 incid fact exp 0% | 314 O.T.S 0% | 315 Cables & Faisce 5% | 316 ELECTRONIQUE 5% | 317 ELECTRONIQUE ES 0% | 318 CLASSIC 15% | 319 FILTR PART ES 0% | 320 PIECES INJECTIO 5% | 321 PIECES CHASSIS 5% | 322 PIECES MOTEUR 5% | 323 PIECES B.V - B. 5% | 324 GALETS TENDEURS 15% | 325 PIECES FREINAGE 5% | 326 PIECES CARROSSE 5% | 327 PIECES ELECTRIC 5% | 328 PCES TRAM METRO 5% | 329 EQUIP SPECIAUX 5% | 330 ORGANES DECOTES 0% | 331 ORGANES CHASSIS 5% | 332 ORGANES MOTEUR 5% | 333 ORGANES B.V - B 5% | 334 PIECES MRE 0% | 335 TURBO NEUF 5% | 336 ORGANES CABINES 5% | 337 PIECES V.A.B 0% | 338 ORGANES V.A.B 0% | 339 COMPR CLIM ES 0% | 340 RESERVOIRS GASO 15% | 341 RESERVOIRS AIR 15% | 342 PIECES MOTEURS 5% | 343 TETE DE PONT ES 5% | 344 DISQUES CONTROL 20% | 345 FILTRES AIR ET 20% | 346 FILTRES GASOLE 20% | 347 FILTRES HUILE 20% | 348 JOINTS D'ETANCH 5% | 349 INJECTEURS 5% | 350 EMBRAYAGE NEUF 15% | 351 EMBRAYAGES ES 15% | 352 DISQUES FREIN 20% | 353 LEVIERS DE FREI 15% | 354 EQPT ES FREIN 15% | 355 INJECTEURS ES 15% | 356 ROULEMENTS 15% | 357 ALTER DEMA ES 15% | 358 EQUIPEMENTS ES 15% | 359 RADIATEURS ES 20% | 360 VASE EXPANSION 15% | 361 RESSORTS A LAME 15% | 362 LAMES DE RESSOR 15% | 363 BATTERIES 20% | 364 GARNITURES DE F 20% | 365 PLAQUETTES DE F 20% | 366 CYL. DE FREINS 15% | 367 FLEXIBLES  AIR 5% | 368 AMORTISSEURS DE 15% | 369 COMPRESSEUR ROB 5% | 370 ESSUIE-GLACE  R 20% | 371 THERMOSTATS MAN 5% | 372 RELAIS ELECT.CO 5% | 373 ALTERNATEUR DEM 5% | 374 LANCEUR.INDUIT. 5% | 375 BLOCS PHARES.PR 15% | 376 FEUX CLIGNOTANT 15% | 377 LAMPES ET BOITE 20% | 378 CARTOU DESSICAT 20% | 379 COSSES FILS FUS 5% | 380 PARE BRISE ENCA 15% | 381 COURROIES ET JE 15% | 382 BAVETTES AILES 15% | 383 RETROVISEURS GL 15% | 384 VISSERIE STANDA 15% | 385 KIT MAINTENANCE 20% | 386 RADIATEUR EAU A 15% | 387 DURITS DROITES 15% | 388 SILENCIEUX ECHA 15% | 389 PIECES EQUIPEME 5% | 390 X 15% | 391 X 15% | 392 POST COMBUSTION 15% | 393 OPTIMISATION 5% | 394 DIVERS STATION 15% | 395 SECURITE 15% | 396 DIVERSIFICATION 5% | 397 SUR LA ROUTE 5% | 398 INFOMAX 5% | 399 INFOMAX 0%\n\nEURO 6:\n601 BV & TRANS ES 5% | 602 MOT COMPLET ES 5% | 603 Gpe EMB MOT NU 5% | 604 DIRECTION ES 5% | 605 REPRISE E/S 0% | 606 FILT PART ES 10% | 607 ELECTRONIQUE ES 5% | 608 TURBOS ES 5% | 609 POST TRAIT ES 5% | 610 ACCESS 5% | 611 GNV 5% | 612 OUTILLAGE SPEC 0% | 613 TRANS ELEC ES 5% | 614 VASE EXPANSION 10% | 615 Cables & Faisce 5% | 616 TRANSMI ELEC 5% | 617 ELECTRONIQUE 5% | 618 FILTRE UREE 15% | 619 POST TRAITEMENT 15% | 620 PCES INJECTION 5% | 621 PCE CHASSIS 5% | 622 PCES MOTEUR 5% | 623 PCES BV BT 5% | 624 TENDEUR DE COUR 15% | 625 FREINAGE SERVIT 5% | 626 PR CARROSSERIE 5% | 627 PR ELECT 5% | 628 COMPRESSEUR 15% | 629 EQUPTS SPEC 5% | 630 ORG INJ 5% | 631 ORG LIAIS SOL 5% | 632 ORG MOTEUR 5% | 633 ORG BV BT 5% | 634 BAT TRACTION ES 5% | 635 DISTRIB ELEC 0% | 636 ORG CAB 5% | 637 BAT TRACTION 5% | 638 TURBO NEUF 5% | 639 COMPR CLIM ES 10% | 640 RESERVOIR GO 15% | 641 RESERVOIR AIR 15% | 642 PR MOTREUR 5% | 643 TETE DE PONT ES 10% | 644 DISQUE TACHO 20% | 645 CART AIR EAU 20% | 646 CART GO 20% | 647 CART HUILE 20% | 648 JOINT 5% | 649 INJ PPE NEUF 5% | 650 EMB NEUF 15% | 651 EMBRAYAGE ES 15% | 652 DISQUE FREIN 20% | 653 PIECE DE DIRECT 15% | 654 EQPT ES FREIN 15% | 655 INJECTEURS ES 15% | 656 RLTS 15% | 657 ALT DEM ES 15% | 658 EQPT ES 15% | 659 RADIATEURS ES 20% | 660 COMPR D AIR ES 20% | 661 RESSORT SUSP LA 15% | 662 DETAIL SUSP LAM 15% | 663 BATTERIE 20% | 664 GARN FREIN 20% | 665 PLAQU FREIN 20% | 666 CYL FREIN 15% | 667 FLEXIBLE 5% | 668 AMORT COUSSIN 15% | 669 COMP CIRCUIT FR 5% | 670 BALAIS EG 20% | 671 APPAREIL CONTRO 5% | 672 COMP ELECTRI 5% | 673 ALT DEM NEUF 5% | 674 PR ALT DEM 5% | 675 ECLAIRAGE 15% | 676 SIGNALISATION 15% | 677 AMPOULE BOITE 20% | 678 CART DESSICCA 20% | 679 COSSE FIL FUSIB 5% | 680 PRE BRISE JOINT 15% | 681 COURROIE 15% | 682 BAVETTE AILE 15% | 683 RETRO GLACE 15% | 684 VISSERIE SPECIF 15% | 685 KIT MAINT FILT 20% | 686 RADIA AIR EAU N 15% | 687 FLEXIBLE EAU 15% | 688 ECHPT SILENCIEU 15% | 689 EQUPT SPEC 5% | 690 PR CONCURRENCE 15% | 691 CARROSSERIE 10% | 692 DISTRIB ELEC ES 0% | 693 OPTIMISATION 5% | 694 DIVERS STATION 15% | 695 SECURITE 15% | 696 VIE A BORD 5% | 697 PERSONNALISATIO 5% | 698 INFOMAX 5% | 699 OPTIFLEET 5%\n\nAUTRES:\n558 COMP MOT E/S -% | 578 COLLIERS DE SER 15% | 583 RETRO 5% | 584 VIS SPEC 5% | 586 RAD AI EAU N 5% | 588 SILEN ECHPT 5% | 591 PDT PROPRETE 5%",
      conditions:
        "Grille Remises Pièces Renault Trucks 2024 (Grille N°635).\nColonnes : Véhicule Utilitaire / Moteurs dCi-Dxi / Euro 6 / Autres — code famille à 3 chiffres.",
      brands: ["Renault Trucks"],
      services: [],
      comments: "Concessionnaire Renault Trucks.",
      pdfPath: "D:\\Contrats\\KETRUCKS\\Copy of GRILLE REMISE.xlsx",
      priority: 6,
      pinned: false,
    },
    {
      provider: "Norauto",
      category: "Pneumatiques & entretien",
      keywords: [
        "pneu", "pneus", "tourisme", "utilitaire",
        "continental", "goodyear", "michelin", "bridgestone", "dunlop", "pirelli",
        "uniroyal", "bfgoodrich", "firestone", "hankook", "nokian",
        "montage", "equilibrage", "permutation", "reparation", "gardiennage",
        "geometrie", "parallelisme", "carrossage",
        "frein", "freinage", "plaquette", "disque",
        "vitrage", "pare-brise", "parebrise", "phare", "carrosserie", "peinture", "jante",
        "revision", "vidange", "entretien", "filtre", "convoyage", "lavage"
      ],
      discount:
        "PNEUS (remise sur Barème Fournisseur / manufacturier) :\nContinental 36.9% | Goodyear 38.9% | Michelin 30.9% | Bridgestone 37.6% | Dunlop 38.9% | Pirelli 41.1% | Uniroyal 32.9% | BFGoodrich 22.2% | Firestone 21% | Hankook 33.6% | Nokian 25.7% | Norauto (MDD) 8%\n\nMAIN D'ŒUVRE PNEUMATIQUES (tarifs HT) :\nForfait pose MEV ≤16\" : 13,00€ | Forfait pose MEV >16\"/runflat : 13,95€ | Forfait pose MEV utilitaire : 13,95€ | Permutation 2 roues : 5,50€ | Changement 1 roue : 5,50€ | Équilibrage véhicule tourisme : 9,00€ | Équilibrage utilitaire : 9,20€ | Réparation crevaison tourisme : 19,50€ | Réparation runflat : 21,65€ | Réparation 4x4/utilitaire : 23,35€ | Gardiennage 6 mois/pneu : 10,50€.\n\nGÉOMÉTRIE/PARALLÉLISME :\nContrôle trains AV+AR : 30,00€ | Contrôle + réglage parallélisme AV : 51,50€ | + carrossage : 63,00€ | Contrôle + réglage AV et AR : 81,65€ | Contrôle + réglage AV/AR + chasse/carrossage : 87,60€.",
      conditions:
        "Grille tarifaire Norauto \"Votre Partenaire Pro\" — mise à jour mars 2023.\nLa remise sur pneumatiques s'applique sur le barème manufacturier en vigueur lors de la prise en charge.\nForfaits freinage et filtre à carburant différenciés par marque/modèle de véhicule (voir grille détaillée).",
      brands: ["Continental", "Goodyear", "Michelin", "Bridgestone", "Dunlop", "Pirelli", "Uniroyal", "BFGoodrich", "Firestone", "Hankook", "Nokian", "Norauto"],
      services: ["Montage pneu", "Équilibrage", "Géométrie", "Freinage", "Vitrage", "Carrosserie", "Convoyage"],
      comments: "Programme \"Ma Révision PRO\" disponible en complément de l'entretien flottes.",
      pdfPath: "D:\\Contrats\\NORAUTO\\Grille Validée.xlsx",
      priority: 6,
      pinned: false,
    },
  ];

  for (const s of samples) {
    await Store.saveAgreement(s);
  }
}

// Un véhicule + une fiche client de démonstration, pour tester tout de suite
// le module "assistant véhicule" (immatriculation -> fiche -> réponses).
// Supprimez-les depuis ⚙ Administration quand vous ajoutez vos propres données.
async function seedVehicleDemoIfEmpty() {
  const existing = await Store.listVehicles();
  if (existing.length > 0) return;

  const agreements = await Store.listAgreements();
  const euromasterVL = agreements.find((a) => (a.provider || "").startsWith("Euromaster (Véhicules Légers)"));

  const fiche = await Store.saveFiche({
    client: "ABC Transport",
    plafond: 750,
    validateurNom: "Jean Dupont",
    validateurCanal: "E-mail",
    garages: euromasterVL ? { Pneumatiques: euromasterVL.id } : {},
    controleTechnique: { centre: "Autovision Gennevilliers", frequence: "Tous les ans", notes: "" },
    assistance: { telephone: "0800 00 00 00", notes: "Disponible 24/7." },
    vehiculeRelais: { autorise: true, notes: "Sur demande, sous réserve de disponibilité." },
    garantie: { notes: "Garantie constructeur en cours (3 ans / 100 000 km)." },
    facturation: { destinataire: "Comptabilité ABC Transport", email: "compta@abc-transport.fr", notes: "" },
    assurance: { compagnie: "AXA Flotte", telephone: "09 70 00 00 00", notes: "Franchise 500 € HT." },
    cartesCarburant: { notes: "Carte Total via Arval, plafond 200 L/mois." },
    peages: { notes: "Badge télépéage fourni par Arval, facturé mensuellement." },
    reglesParticulieres: { notes: "" },
    contacts: [{ label: "Responsable flotte", value: "Jean Dupont, 06 12 34 56 78" }],
  });

  await Store.saveVehicle({
    plate: "AA-855-ZA",
    client: "ABC Transport",
    company: "ABC Transport SARL",
    brand: "Renault",
    model: "Master",
    vin: "",
    mileage: 45000,
    renter: "Arval",
    center: "Gennevilliers",
    driver: "",
    ficheId: fiche.id,
    contractRef: "",
    contractPath: "",
    allowedProviders: [],
    history: "",
  });
}

chrome.runtime.onStartup.addListener(() => {
  checkExpiringAgreements();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) {
    checkExpiringAgreements();
  }
});

async function checkExpiringAgreements() {
  const { expiringSoon } = await Store.computeDashboard();
  if (!expiringSoon.length) return;

  // Évite de re-notifier plusieurs fois le même jour pour les mêmes contrats
  const today = new Date().toISOString().slice(0, 10);
  const { lastNotifiedDay, lastNotifiedIds } = await chrome.storage.local.get([
    "lastNotifiedDay",
    "lastNotifiedIds",
  ]);

  const currentIds = expiringSoon.map((a) => a.id).sort().join(",");
  if (lastNotifiedDay === today && lastNotifiedIds === currentIds) {
    return;
  }

  const title =
    expiringSoon.length === 1
      ? "Un contrat arrive à expiration"
      : `${expiringSoon.length} contrats arrivent à expiration`;

  const message = expiringSoon
    .slice(0, 3)
    .map((a) => `${a.provider} — expire le ${new Date(a.endDate).toLocaleDateString("fr-FR")}`)
    .join("\n");

  chrome.notifications.create(`expiring-${today}`, {
    type: "basic",
    iconUrl: "icons/icon128.png",
    title,
    message: message + (expiringSoon.length > 3 ? `\n+ ${expiringSoon.length - 3} autre(s)` : ""),
    priority: 2,
  });

  await chrome.storage.local.set({ lastNotifiedDay: today, lastNotifiedIds: currentIds });
}

chrome.notifications.onClicked.addListener(() => {
  chrome.runtime.openOptionsPage();
});
