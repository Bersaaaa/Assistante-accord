/**
 * search.js
 * Moteur de compréhension d'intention "maison", sans dépendance externe.
 * Il ne se contente pas d'un match de mot-clé strict : il normalise,
 * étend via un dictionnaire de synonymes métier, et pondère par
 * priorité / fraîcheur du contrat.
 */

// Dictionnaire de synonymes métier -> termes canoniques.
// Sert à faire remonter un accord même si le collaborateur n'utilise pas
// exactement les mots-clés saisis par l'administrateur.
const SYNONYM_GROUPS = [
  ["pneu", "pneus", "pneumatique", "pneumatiques", "roue", "roues", "train avant", "train arrière", "michelin", "continental", "goodyear", "montage", "equilibrage", "équilibrage"],
  ["pare-brise", "parebrise", "vitrage", "vitre", "glace", "lunette arrière", "lunette", "impact", "bris de glace"],
  ["vidange", "entretien", "huile", "revision", "révision", "filtre", "filtre a huile"],
  ["batterie", "demarreur", "démarreur", "accu"],
  ["distribution", "courroie", "courroie de distribution", "chaine de distribution", "chaîne de distribution"],
  ["frein", "freins", "plaquette", "plaquettes", "disque", "disques"],
  ["carrosserie", "choc", "bosse", "rayure", "peinture"],
  ["climatisation", "clim", "gaz clim"],
];

function normalize(str) {
  return (str || "")
    .toString()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // enlève les accents
    .replace(/[^a-z0-9\s-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function expandQueryTerms(query) {
  const norm = normalize(query);
  const tokens = new Set(norm.split(" ").filter(Boolean));
  // ajoute les phrases complètes normalisées aussi (pour "train avant" etc.)
  tokens.add(norm);

  const expanded = new Set(tokens);
  for (const group of SYNONYM_GROUPS) {
    const groupNorm = group.map(normalize);
    const matches = groupNorm.some((g) => norm.includes(g));
    if (matches) {
      groupNorm.forEach((g) => expanded.add(g));
    }
  }
  return expanded;
}

// Détecte des intentions structurées type "quelle remise chez X" / "le
// client peut aller chez X" pour prioriser une recherche directe par
// nom de prestataire plutôt qu'une recherche par catégorie.
//
// Le nom affiché d'un accord peut porter un qualificatif entre parenthèses
// ("Profil Plus (Véhicules Légers)", "Euromaster (Poids Lourds)") : on
// compare donc aussi contre le nom de base, sans le qualificatif, pour que
// "remise profil plus" retrouve l'accord même si l'utilisateur ne précise
// pas VL/PL. En cas d'ambiguïté entre plusieurs variantes du même
// prestataire, on départage avec le score de mots-clés, puis la priorité.
function providerBaseName(provider) {
  return (provider || "").split(" (")[0].trim();
}

function extractExplicitProvider(query, agreements, expandedTerms) {
  const norm = normalize(query);
  const candidates = [];
  for (const a of agreements) {
    const fullName = normalize(a.provider);
    const baseName = normalize(providerBaseName(a.provider));
    if (fullName && norm.includes(fullName)) {
      candidates.push({ agreement: a, specificity: fullName.length });
    } else if (baseName && baseName.length >= 3 && norm.includes(baseName)) {
      candidates.push({ agreement: a, specificity: baseName.length });
    }
  }
  if (candidates.length === 0) return null;
  if (candidates.length === 1) return candidates[0].agreement;

  // Plusieurs variantes du même prestataire (ex: VL et PL) : on choisit
  // celle dont les mots-clés/catégorie collent le mieux à la requête,
  // sinon celle avec le nom le plus spécifique, sinon la priorité la plus haute.
  candidates.sort((a, b) => {
    const scoreA = scoreAgreement(a.agreement, expandedTerms || new Set());
    const scoreB = scoreAgreement(b.agreement, expandedTerms || new Set());
    if (scoreB !== scoreA) return scoreB - scoreA;
    if (b.specificity !== a.specificity) return b.specificity - a.specificity;
    return (Number(b.agreement.priority) || 0) - (Number(a.agreement.priority) || 0);
  });
  return candidates[0].agreement;
}

function scoreAgreement(agreement, expandedTerms) {
  const haystack = new Set();
  const addAll = (arr) => (arr || []).forEach((s) => haystack.add(normalize(s)));

  addAll([agreement.category]);
  addAll(agreement.keywords);
  addAll(agreement.brands);
  addAll(agreement.services);

  let termScore = 0;
  for (const term of expandedTerms) {
    if (!term) continue;
    for (const h of haystack) {
      if (!h) continue;
      if (h === term) {
        termScore += 3;
      } else if (term.length >= 4 && h.length >= 4 && (h.includes(term) || term.includes(h))) {
        // Le containment partiel n'est autorisé qu'à partir de 4 caractères :
        // sinon un mot-clé court comme "pl" ou "mo" matche par accident
        // n'importe quelle requête contenant "plus", "moteur", etc.
        termScore += 1.5;
      }
    }
  }
  // Les bonus (priorité, épinglage) ne comptent que s'il y a déjà une
  // correspondance réelle sur les mots-clés : sinon un accord pourrait
  // remonter uniquement parce qu'il a une priorité élevée, sans rapport
  // avec la question posée.
  if (termScore <= 0) return 0;

  let score = termScore;
  score += (Number(agreement.priority) || 0) * 0.3;
  if (agreement.pinned) score += 0.5;
  return score;
}

// ---------------------------------------------------------------------
// Filtrage des remises affichées : le champ "discount" d'un accord peut
// contenir un barème complet (toutes les marques, toutes les familles de
// pièces...). On ne veut afficher, dans la carte de réponse, que les
// lignes qui concernent réellement la question posée — le reste reste
// accessible via un bouton "Voir tout le détail".
// ---------------------------------------------------------------------

// Découpe un texte de remise en { section, text } : une ligne qui se
// termine par ":" et ne contient pas de "|" est un titre de section: les
// lignes suivantes sont des entrées (séparées par "|" ou une par ligne).
function parseDiscountEntries(text) {
  const lines = (text || "").split("\n");
  let section = null;
  const entries = [];
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    if (line.endsWith(":") && !line.includes("|")) {
      section = line.replace(/:$/, "").trim();
      continue;
    }
    const parts = line
      .split("|")
      .map((p) => p.trim())
      .filter(Boolean);
    for (const p of parts) {
      entries.push({ section, text: p });
    }
  }
  return entries;
}

function pickRelevantDiscount(discountText, expandedTerms, maxEntries = 8) {
  const entries = parseDiscountEntries(discountText);
  if (entries.length === 0) {
    return { lines: [], sections: [], filtered: false, totalMatches: 0 };
  }

  const matched = entries.filter((e) => {
    const normEntry = normalize(e.text);
    for (const term of expandedTerms) {
      if (!term || term.length < 3) continue;
      if (normEntry.includes(term) || (term.length >= 4 && term.includes(normEntry))) {
        return true;
      }
    }
    return false;
  });

  if (matched.length === 0) {
    // Rien de précis demandé (ex: "quelle remise chez Feu Vert ?") : on
    // renvoie juste la liste des catégories couvertes, pas le détail.
    const sections = [...new Set(entries.map((e) => e.section).filter(Boolean))];
    return { lines: [], sections, filtered: false, totalMatches: 0 };
  }

  return {
    lines: matched.slice(0, maxEntries).map((e) => e.text),
    sections: [...new Set(matched.map((e) => e.section).filter(Boolean))],
    filtered: true,
    totalMatches: matched.length,
    truncated: matched.length > maxEntries,
  };
}

/**
 * Résout une requête utilisateur en résultat exploitable par le chat.
 * Retourne un objet décrivant le type de réponse à afficher.
 */
function resolveQuery(query, agreements) {
  const now = new Date();
  const active = agreements.filter((a) => {
    if (a.startDate && new Date(a.startDate) > now) return false;
    if (a.endDate && new Date(a.endDate) < now) return false;
    return true;
  });

  const norm = normalize(query);
  const expandedTerms = expandQueryTerms(query);

  // 1) Le collaborateur cite un nom de prestataire connu -> réponse directe
  const explicit = extractExplicitProvider(query, agreements, expandedTerms);

  // 2) Détection d'une négation implicite : "chez X" où X n'est dans aucun accord
  //    On cherche un nom propre après "chez" / "avec" qui ne matche aucun prestataire.
  const chezMatch = norm.match(/(?:chez|avec)\s+([a-z0-9\s-]{2,30})$/);
  let unknownProviderMentioned = null;
  if (chezMatch && !explicit) {
    unknownProviderMentioned = chezMatch[1].trim();
  }

  const scored = active
    .map((a) => ({ agreement: a, score: scoreAgreement(a, expandedTerms) }))
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score);

  const withRelevantDiscount = (agreement, terms) => ({
    agreement,
    relevantDiscount: pickRelevantDiscount(agreement.discount, terms || expandedTerms),
  });

  if (explicit) {
    // Pour une question directe ("quelle remise chez Feu Vert ?"), on
    // retire le nom du prestataire des termes de recherche avant de filtrer
    // les lignes de remise : sinon un prestataire dont le nom recoupe une
    // marque qu'il vend (ex: Feu Vert vend aussi des pneus "Feu Vert")
    // afficherait cette ligne par accident même sans produit précisé.
    const providerNameWords = new Set(
      [normalize(explicit.provider), normalize(providerBaseName(explicit.provider))]
        .join(" ")
        .split(" ")
        .filter(Boolean)
    );
    const termsWithoutProviderName = new Set(
      [...expandedTerms].filter((t) => t && !providerNameWords.has(t))
    );
    return { type: "direct_provider", ...withRelevantDiscount(explicit, termsWithoutProviderName) };
  }

  if (unknownProviderMentioned && scored.length === 0) {
    // Aucun mot-clé métier n'a matché non plus : on ne peut rien recommander
    return { type: "no_agreement", mentioned: unknownProviderMentioned, alternative: null };
  }

  if (unknownProviderMentioned && scored.length > 0) {
    return {
      type: "no_agreement",
      mentioned: unknownProviderMentioned,
      ...withRelevantDiscount(scored[0].agreement),
      alternative: scored[0].agreement,
    };
  }

  if (scored.length === 0) {
    return { type: "not_found" };
  }

  return {
    type: "match",
    ...withRelevantDiscount(scored[0].agreement),
    alternatives: scored.slice(1, 4).map((s) => s.agreement),
  };
}

// =======================================================================
// MODULE VÉHICULES / FICHE D'EXPLOITATION
// Permet à un collaborateur de saisir une immatriculation puis de discuter
// en langage naturel : l'IA garde le véhicule sélectionné en mémoire de
// conversation et répond avec les règles de gestion du client (plafond,
// validateur, garages recommandés, assistance, etc.).
// =======================================================================

// Formats FF : SIV (AA-123-AA) et FNI (123 ABC 75 / 1234 AB 75).
const PLATE_REGEXES = [
  /\b([A-Z]{2})[\s-]?(\d{3})[\s-]?([A-Z]{2})\b/, // SIV depuis 2009
  /\b(\d{2,4})[\s-]?([A-Z]{2,3})[\s-]?(\d{2,3})\b/, // FNI (ancien format)
];

function extractPlate(text) {
  const upper = (text || "").toString().toUpperCase().trim();
  if (!upper) return null;
  for (const re of PLATE_REGEXES) {
    const m = upper.match(re);
    if (m) return m[0].replace(/\s+/g, "-");
  }
  return null;
}

// Une question qui contient une immatriculation ET du texte autour
// ("les pneus de AA-855-ZA") ne doit pas être traitée comme un simple
// changement de véhicule sélectionné, mais bien comme une question sur ce
// véhicule. On considère que la saisie est "juste une plaque" si, une fois
// la plaque retirée, il ne reste presque rien.
function isPlateOnlyInput(text, plate) {
  const stripped = normalize(text).replace(normalize(plate), "").trim();
  return stripped.length <= 2;
}

// Intentions "métier" reconnues sur un véhicule, avec leurs synonymes.
// Chaque groupe est indépendant des SYNONYM_GROUPS (accords) : ceux-ci
// restent utilisés pour choisir *quel prestataire* recommander une fois
// l'intention "catégorie d'atelier" détectée.
const VEHICLE_INTENTS = [
  { key: "find_garage_nearby", terms: ["garage pres de moi", "garage près de moi", "garage a proximite", "garage à proximité", "garage proche", "autour de moi", "pres de chez moi", "près de chez moi", "trouver un garage", "garage le plus proche"] },
  { key: "plafond", terms: ["plafond", "montant maximum", "montant max", "seuil", "sans accord"] },
  { key: "devis_check", terms: ["devis de", "devis a", "devis à", "ca coute", "ça coûte", "combien ca fait", "montant du devis"] },
  { key: "controle_technique", terms: ["controle technique", "ct", "contre visite", "mines"] },
  { key: "assistance", terms: ["assistance", "depannage", "dépannage", "panne", "remorquage", "immobilisation"] },
  { key: "vehicule_relais", terms: ["vehicule relais", "véhicule relais", "vehicule de courtoisie", "véhicule de courtoisie", "vehicule de pret", "véhicule de prêt", "voiture de remplacement"] },
  { key: "garantie", terms: ["garantie", "sav", "service apres vente", "service après-vente"] },
  { key: "facturation", terms: ["facture", "facturation", "qui recoit les factures", "qui reçoit les factures", "envoyer la facture"] },
  { key: "validateur", terms: ["qui valide", "validateur", "qui autorise", "responsable flotte", "qui donne l accord", "qui donne l'accord"] },
  { key: "contrat", terms: ["contrat", "clauses", "que prevoit le contrat", "que prévoit le contrat", "loueur"] },
  { key: "assurance", terms: ["assurance", "sinistre", "constat", "assureur"] },
  { key: "carte_carburant", terms: ["carte carburant", "carburant", "essence", "carte total", "carte de carburant"] },
  { key: "peage", terms: ["peage", "péage", "badge peage", "badge télépéage", "telepeage", "télépéage"] },
  { key: "contact", terms: ["qui appeler", "numero", "numéro", "contact", "telephone", "téléphone"] },
  // Catégories d'atelier : on réutilise le vocabulaire des accords fournisseurs.
  { key: "cat_pneus", terms: SYNONYM_GROUPS[0], category: "Pneumatiques" },
  { key: "cat_pare_brise", terms: SYNONYM_GROUPS[1], category: "Vitrage" },
  { key: "cat_vidange", terms: SYNONYM_GROUPS[2], category: "Entretien" },
  { key: "cat_batterie", terms: SYNONYM_GROUPS[3], category: "Batterie" },
  { key: "cat_distribution", terms: SYNONYM_GROUPS[4], category: "Distribution" },
  { key: "cat_frein", terms: SYNONYM_GROUPS[5], category: "Freinage" },
  { key: "cat_carrosserie", terms: SYNONYM_GROUPS[6], category: "Carrosserie" },
  { key: "cat_clim", terms: SYNONYM_GROUPS[7], category: "Climatisation" },
];

// "où faire les pneus", "quel garage", "où envoyer le véhicule" sans
// précision -> par défaut on part sur une intention "atelier générique"
// qui se résout via le dernier sujet évoqué ou, à défaut, demande de préciser.
const GENERIC_GARAGE_TERMS = ["garage", "atelier", "prestataire", "ou envoyer", "où envoyer", "reparer", "réparer", "reparation", "réparation"];

// Compare la question à un terme de vocabulaire métier. En plus de la
// correspondance directe, on tolère les abréviations courantes du métier
// (ex : "distrib" pour "distribution", "batterie" reste "batterie" mais
// "carrosse" matcherait "carrosserie") : un mot de la question d'au moins
// 5 lettres qui est un préfixe d'un mot du terme (ou l'inverse) compte comme
// une correspondance.
function matchesTerm(norm, t) {
  if (!t) return false;
  if (norm.includes(t)) return true;
  const queryWords = norm.split(" ");
  const termWords = t.split(" ");
  return queryWords.some((qw) => {
    if (qw.length < 5) return false;
    return termWords.some((tw) => tw.length >= 5 && (tw.startsWith(qw) || qw.startsWith(tw)));
  });
}

function detectVehicleIntent(query) {
  const norm = normalize(query);
  for (const intent of VEHICLE_INTENTS) {
    for (const term of intent.terms) {
      const t = normalize(term);
      if (matchesTerm(norm, t)) return intent;
    }
  }
  const isGeneric = GENERIC_GARAGE_TERMS.some((t) => matchesTerm(norm, normalize(t)));
  if (isGeneric) return { key: "cat_generic" };
  return null;
}

// Extrait un montant en euros d'une question ("devis de 1 200 €", "ça fait 850 euros").
function extractAmount(text) {
  const m = (text || "").toString().match(/(\d[\d\s]{0,6}(?:[.,]\d{1,2})?)\s*(?:€|eur\b|euros?\b)/i);
  if (!m) return null;
  const raw = m[1].replace(/\s/g, "").replace(",", ".");
  const val = parseFloat(raw);
  return Number.isFinite(val) ? val : null;
}

function fmtEuros(n) {
  return `${Number(n).toLocaleString("fr-FR")} € HT`;
}

// Recherche un accord correspondant à la marque du véhicule (ex :
// concessionnaire Iveco). On ne filtre pas par catégorie : un concessionnaire
// de marque couvre en général tous les besoins d'atelier pour cette marque,
// et les libellés de catégorie saisis par l'utilisateur sont du texte libre
// qui ne correspond pas forcément mot pour mot aux catégories internes.
//
// IMPORTANT : s'il existe plusieurs accords pour cette marque (plusieurs
// concessions dans des régions différentes), on essaie de retenir celle qui
// couvre le centre de rattachement du véhicule (comparaison texte sur
// l'adresse/le nom de l'accord). Si aucune concession ne correspond
// clairement à la région du véhicule, on renvoie quand même la meilleure
// disponible, mais avec `locationVerified: false` pour que l'interface
// prévienne l'utilisateur au lieu de l'imposer silencieusement à des
// centaines de km.
function findAgreementForBrandDealer(brand, agreements, center) {
  if (!brand) return { agreement: null, locationVerified: false };
  const nb = normalize(brand);
  const matches = agreements.filter((a) => {
    const inBrands = (a.brands || []).some((b) => normalize(b) === nb);
    const inName = normalize(a.provider || "").includes(nb);
    return inBrands || inName;
  });
  if (!matches.length) return { agreement: null, locationVerified: false };

  matches.sort((a, b) => (b.priority || 0) - (a.priority || 0));

  if (center) {
    const nc = normalize(center);
    const localMatches = matches.filter((a) => {
      const haystack = normalize(`${a.address || ""} ${a.provider || ""} ${a.comments || ""}`);
      return nc && haystack.includes(nc);
    });
    if (localMatches.length) return { agreement: localMatches[0], locationVerified: true };
  }

  // Aucune concession clairement rattachée au centre du véhicule : on
  // renvoie la meilleure dispo quand même, mais non vérifiée.
  return { agreement: matches[0], locationVerified: !center };
}

// Trouve, parmi les règles de marque (globales, indépendantes du client),
// celle qui s'applique à cette marque de véhicule pour cette catégorie.
// Une règle sans "categories" définies s'applique à toutes les catégories
// (ex : "Iveco -> concession Iveco quoi qu'il arrive").
function matchBrandRule(brand, category, brandRules) {
  if (!brand || !brandRules || !brandRules.length) return null;
  const nb = normalize(brand);
  return (
    brandRules.find((r) => {
      if (normalize(r.brand || "") !== nb) return false;
      if (!r.categories || !r.categories.length) return true;
      if (!category) return false;
      return r.categories.some((c) => normalize(c) === normalize(category));
    }) || null
  );
}

// Résout, pour une catégorie d'atelier donnée, quel prestataire recommander,
// dans l'ordre de priorité métier :
// 1) règle de marque exclusive (ex : Iveco -> concession Iveco uniquement),
//    qui prime sur tout — y compris les préférences du client
// 2) obligation/préférence enregistrée sur la fiche client
// 3) sinon, moteur de correspondance générique sur les accords actifs
function resolveGarageForCategory({ category, query, fiche, agreements, vehicle, brandRules }) {
  const brandRule = matchBrandRule(vehicle?.brand, category, brandRules);
  if (brandRule && brandRule.exclusiveOfficialDealer) {
    const { agreement: dealer, locationVerified } = findAgreementForBrandDealer(vehicle?.brand, agreements, vehicle?.center);
    return {
      exclusive: true,
      reason: "brand_rule",
      brandRule,
      agreement: dealer,
      noLocalMatch: !dealer,
      locationVerified,
    };
  }

  const ficheEntry = fiche && fiche.garages && fiche.garages[category];
  if (ficheEntry) {
    const entryId = typeof ficheEntry === "string" ? ficheEntry : ficheEntry.agreementId;
    const entryExclusive = typeof ficheEntry === "object" && !!ficheEntry.exclusive;
    const preferred = agreements.find((a) => a.id === entryId);
    if (preferred) {
      return { agreement: preferred, exclusive: entryExclusive, reason: entryExclusive ? "fiche_exclusive" : "fiche_preference" };
    }
  }

  const result = resolveQuery(query, agreements);
  if (result.type === "match" || result.type === "direct_provider") {
    return { agreement: result.agreement, relevantDiscount: result.relevantDiscount, exclusive: false, reason: "auto" };
  }
  return null;
}

/**
 * Résout une question posée alors qu'un véhicule est sélectionné dans la
 * conversation. Retourne un objet { type, ... } consommé par popup.js.
 */
function resolveVehicleQuery({ query, vehicle, fiche, agreements, brandRules = [] }) {
  const intent = detectVehicleIntent(query);
  const amount = extractAmount(query);

  // Un montant chiffré prime toujours : "devis de 1200 €" doit être comparé
  // au plafond même si l'utilisateur n'emploie pas le mot "devis"/"plafond".
  if (amount !== null && fiche && fiche.plafond) {
    const overCeiling = amount > Number(fiche.plafond);
    return {
      type: "devis_check",
      amount,
      overCeiling,
      fiche,
      vehicle,
    };
  }

  if (!intent) return { type: "vehicle_unresolved" };

  switch (intent.key) {
    case "find_garage_nearby": {
      // On remonte les éventuelles règles imposées (marque, ou fiche client
      // sur "Entretien") pour que la recherche géolocalisée les respecte
      // au lieu de proposer des alternatives non autorisées.
      const brandRule = matchBrandRule(vehicle?.brand, null, brandRules);
      const ficheEntretien = fiche && fiche.garages && fiche.garages["Entretien"];
      const ficheExclusive = ficheEntretien && typeof ficheEntretien === "object" && ficheEntretien.exclusive
        ? agreements.find((a) => a.id === ficheEntretien.agreementId)
        : null;
      return { type: "find_garage_nearby", vehicle, brandRule: brandRule && brandRule.exclusiveOfficialDealer ? brandRule : null, ficheExclusiveAgreement: ficheExclusive };
    }

    case "plafond":
    case "validateur":
      if (!fiche) return { type: "no_fiche", vehicle };
      return { type: "plafond", fiche, vehicle };

    case "devis_check":
      if (!fiche || !fiche.plafond) return { type: "no_fiche", vehicle };
      return { type: "devis_check", amount: amount ?? null, overCeiling: amount !== null ? amount > Number(fiche.plafond) : null, fiche, vehicle, needsAmount: amount === null };

    case "controle_technique":
      if (!fiche || !fiche.controleTechnique) return { type: "no_fiche", vehicle };
      return { type: "controle_technique", fiche, vehicle };

    case "assistance":
      if (!fiche || !fiche.assistance) return { type: "no_fiche", vehicle };
      return { type: "assistance", fiche, vehicle };

    case "vehicule_relais":
      if (!fiche || !fiche.vehiculeRelais) return { type: "no_fiche", vehicle };
      return { type: "vehicule_relais", fiche, vehicle };

    case "garantie":
      if (!fiche || !fiche.garantie) return { type: "no_fiche", vehicle };
      return { type: "garantie", fiche, vehicle };

    case "facturation":
      if (!fiche || !fiche.facturation) return { type: "no_fiche", vehicle };
      return { type: "facturation", fiche, vehicle };

    case "assurance":
      if (!fiche || !fiche.assurance) return { type: "no_fiche", vehicle };
      return { type: "assurance", fiche, vehicle };

    case "carte_carburant":
      if (!fiche || !fiche.cartesCarburant) return { type: "no_fiche", vehicle };
      return { type: "carte_carburant", fiche, vehicle };

    case "peage":
      if (!fiche || !fiche.peages) return { type: "no_fiche", vehicle };
      return { type: "peage", fiche, vehicle };

    case "contrat":
      return { type: "contrat", vehicle };

    case "contact":
      if (!fiche || !(fiche.contacts && fiche.contacts.length)) return { type: "no_fiche", vehicle };
      return { type: "contact", fiche, vehicle };

    case "cat_generic": {
      const brandRule = matchBrandRule(vehicle?.brand, null, brandRules);
      if (brandRule && brandRule.exclusiveOfficialDealer) {
        const { agreement: dealer, locationVerified } = findAgreementForBrandDealer(vehicle?.brand, agreements, vehicle?.center);
        return { type: "garage", vehicle, exclusive: true, reason: "brand_rule", brandRule, agreement: dealer, noLocalMatch: !dealer, locationVerified };
      }
      const result = resolveQuery(query, agreements);
      if (result.type === "match" || result.type === "direct_provider") {
        return { type: "garage", agreement: result.agreement, relevantDiscount: result.relevantDiscount, vehicle, exclusive: false, reason: "auto" };
      }
      return { type: "vehicle_unresolved" };
    }

    default: {
      if (!intent.key.startsWith("cat_")) return { type: "vehicle_unresolved" };
      const garage = resolveGarageForCategory({ category: intent.category, query, fiche, agreements, vehicle, brandRules });
      if (!garage) return { type: "vehicle_unresolved" };
      return { type: "garage", category: intent.category, vehicle, ...garage };
    }
  }
}

self.SearchEngine = {
  resolveQuery,
  normalize,
  expandQueryTerms,
  pickRelevantDiscount,
  extractPlate,
  isPlateOnlyInput,
  detectVehicleIntent,
  extractAmount,
  fmtEuros,
  resolveVehicleQuery,
};
