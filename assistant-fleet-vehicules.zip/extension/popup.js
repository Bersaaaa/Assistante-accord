/**
 * popup.js
 * Vue + contrôleur de la fenêtre principale (chat, dashboard, favoris,
 * historique). Le modèle est délégué à storage.js et search.js.
 */

const els = {
  messages: document.getElementById("messages"),
  emptyState: document.getElementById("emptyState"),
  suggestions: document.getElementById("suggestions"),
  composer: document.getElementById("composer"),
  chatInput: document.getElementById("chatInput"),
  agreementCount: document.getElementById("agreementCount"),
  statGrid: document.getElementById("statGrid"),
  expiringList: document.getElementById("expiringList"),
  pinnedList: document.getElementById("pinnedList"),
  historyList: document.getElementById("historyList"),
  vehicleBar: document.getElementById("vehicleBar"),
  vbPlate: document.getElementById("vbPlate"),
  vbSub: document.getElementById("vbSub"),
  vbClearBtn: document.getElementById("vbClearBtn"),
};

const SUGGESTIONS = [
  "Le client veut changer ses pneus",
  "Où envoyer pour un pare-brise ?",
  "Quelle remise chez Feu Vert ?",
  "Il faut une batterie",
];

let agreementsCache = [];

// ---------------- Mémoire de conversation véhicule ----------------
// Tant qu'un véhicule est sélectionné, toutes les questions du chat lui
// sont automatiquement rattachées, jusqu'à saisie d'une autre immatriculation
// ou clic sur ✕ dans la barre véhicule.
const vehicleContext = { vehicle: null, fiche: null };

function renderVehicleBar() {
  const v = vehicleContext.vehicle;
  if (!v) {
    els.vehicleBar.classList.add("hidden");
    return;
  }
  els.vehicleBar.classList.remove("hidden");
  els.vbPlate.textContent = v.plate || "—";
  const sub = [v.brand, v.model, v.client, v.renter].filter(Boolean).join(" · ");
  els.vbSub.textContent = sub;
}

async function selectVehicle(vehicle) {
  vehicleContext.vehicle = vehicle;
  vehicleContext.fiche = await Store.getFicheForVehicle(vehicle);
  renderVehicleBar();
}

function clearVehicleContext() {
  vehicleContext.vehicle = null;
  vehicleContext.fiche = null;
  renderVehicleBar();
}

els.vbClearBtn.addEventListener("click", () => {
  clearVehicleContext();
  addBotPlainMessage("Véhicule désélectionné. Saisissez une nouvelle immatriculation pour continuer.");
});

async function refreshHeader() {
  agreementsCache = await Store.listAgreements();
  els.agreementCount.textContent = `${agreementsCache.length} accord${agreementsCache.length > 1 ? "s" : ""} chargé${agreementsCache.length > 1 ? "s" : ""}`;
}

function renderSuggestions() {
  els.suggestions.innerHTML = "";
  SUGGESTIONS.forEach((s) => {
    const chip = document.createElement("button");
    chip.className = "suggestion-chip";
    chip.type = "button";
    chip.textContent = s;
    chip.addEventListener("click", () => {
      els.chatInput.value = s;
      handleSubmit();
    });
    els.suggestions.appendChild(chip);
  });
}

function scrollToBottom() {
  els.messages.scrollTop = els.messages.scrollHeight;
}

function addUserMessage(text) {
  els.emptyState.classList.add("hidden");
  const row = document.createElement("div");
  row.className = "msg-row user";
  row.innerHTML = `<div class="msg-bubble"></div>`;
  row.querySelector(".msg-bubble").textContent = text;
  els.messages.appendChild(row);
  scrollToBottom();
}

function escapeHtml(str) {
  const d = document.createElement("div");
  d.textContent = str ?? "";
  return d.innerHTML;
}

function formatDate(d) {
  if (!d) return "";
  try {
    return new Date(d).toLocaleDateString("fr-FR");
  } catch {
    return d;
  }
}

function mapsUrl(query) {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
}

function buildTicketHtml(agreement, { status, eyebrow, negativeIntro, relevantDiscount, vehicleActions } = {}) {
  const statusClass = `status-${status}`;
  const icon = status === "success" ? "🟢" : status === "info" ? "🔵" : "❌";

  const keywordTags = (agreement.keywords || [])
    .slice(0, 6)
    .map((k) => `<span class="keyword-tag">${escapeHtml(k)}</span>`)
    .join(" ");

  // On n'affiche que la remise pertinente pour la question posée : le
  // barème complet reste accessible via "Voir tout le détail" plutôt que
  // de noyer la réponse.
  let discountHtml = "";
  if (agreement.discount) {
    const rd = relevantDiscount;
    if (rd && rd.filtered && rd.lines.length) {
      const list = rd.lines
        .map((l) => `<div class="ticket-row" style="margin:2px 0;"><span class="check">✔</span> ${escapeHtml(l)}</div>`)
        .join("");
      discountHtml = `
        <div style="margin:6px 0 2px;">
          <div style="font-size:11px; color:var(--text-faint); text-transform:uppercase; letter-spacing:.04em; margin-bottom:4px;">Remise${rd.totalMatches > 1 ? "s" : ""} correspondant à votre question</div>
          ${list}
          ${rd.truncated ? `<div style="font-size:11.5px; color:var(--text-faint); margin-top:2px;">+ ${rd.totalMatches - rd.lines.length} autre(s) résultat(s) — voir le détail complet</div>` : ""}
        </div>`;
    } else {
      const sectionHint =
        rd && rd.sections && rd.sections.length
          ? `Catégories couvertes : ${rd.sections.slice(0, 5).map(escapeHtml).join(", ")}${rd.sections.length > 5 ? "…" : ""}`
          : "Précisez un produit (pneus, freinage, batterie…) pour voir la remise exacte, ou consultez le détail complet.";
      discountHtml = `<div class="ticket-row"><span class="check">✔</span> ${sectionHint}</div>`;
    }
  }

  const addressRow = agreement.address
    ? `<div class="ticket-row"><span class="check">✔</span> ${escapeHtml(agreement.address)}</div>`
    : "";

  return `
    <div class="ticket ${statusClass}" data-agreement-id="${agreement.id}">
      ${negativeIntro ? `<div class="ticket-row" style="color:var(--danger); margin-bottom:8px;">${negativeIntro}</div>` : ""}
      <div class="ticket-header ${statusClass}">${icon} ${escapeHtml(eyebrow || "Prestataire")}</div>
      <div class="ticket-title">${escapeHtml(agreement.provider || "—")}</div>
      <div class="ticket-row"><span class="check">✔</span> Catégorie : <strong>${escapeHtml(agreement.category || "—")}</strong></div>
      ${discountHtml}
      ${agreement.services && agreement.services.length ? `<div class="ticket-row"><span class="check">✔</span> ${escapeHtml(agreement.services.join(", "))}</div>` : ""}
      ${addressRow}
      ${agreement.conditions ? `<div class="ticket-conditions">${escapeHtml(agreement.conditions)}</div>` : ""}
      <div class="ticket-full-discount hidden" data-full-discount style="margin-top:8px; padding-top:8px; border-top:1px dashed var(--border); font-size:12px; color:var(--text-dim); white-space:pre-line;"></div>
      ${keywordTags ? `<div style="margin-top:8px; display:flex; flex-wrap:wrap; gap:4px;">${keywordTags}</div>` : ""}
      <div class="ticket-footer">
        <span class="pill">📄 ${escapeHtml(agreement.pdfPath ? agreement.pdfPath.split(/[\\/]/).pop() : "aucun fichier")}</span>
        <div class="ticket-actions">
          ${agreement.discount ? `<button class="btn btn-ghost" data-action="toggle-full-discount" data-id="${agreement.id}">📊 Voir tout le détail</button>` : ""}
          ${agreement.pdfPath ? `<button class="btn btn-ghost" data-action="open-pdf" data-path="${escapeHtml(agreement.pdfPath)}">📂 Ouvrir le contrat</button>` : ""}
          ${vehicleActions && (agreement.address || agreement.provider) ? `<button class="btn btn-ghost" data-action="open-maps" data-query="${escapeHtml(agreement.address || agreement.provider)}">📍 Ouvrir Maps</button>` : ""}
          ${vehicleActions && agreement.phone ? `<button class="btn btn-ghost" data-action="call" data-phone="${escapeHtml(agreement.phone)}">📞 Appeler</button>` : ""}
          ${vehicleActions ? `<button class="btn btn-ghost" data-action="book-rdv" data-id="${agreement.id}">📅 Prendre RDV</button>` : ""}
          <button class="btn btn-ghost" data-action="copy-info" data-id="${agreement.id}">📋 Copier</button>
          <button class="btn btn-ghost" data-action="toggle-pin" data-id="${agreement.id}">${agreement.pinned ? "★ Épinglé" : "☆ Épingler"}</button>
        </div>
      </div>
    </div>
  `;
}

function addBotTicket(html) {
  const row = document.createElement("div");
  row.className = "msg-row bot";
  row.innerHTML = `<div class="msg-bubble">${html}</div>`;
  els.messages.appendChild(row);
  scrollToBottom();
  wireTicketActions(row);
}

function addBotPlainMessage(text) {
  const row = document.createElement("div");
  row.className = "msg-row bot";
  row.innerHTML = `<div class="ticket status-danger"><div class="ticket-row">${escapeHtml(text)}</div></div>`;
  els.messages.appendChild(row);
  scrollToBottom();
}

function wireTicketActions(scope) {
  scope.querySelectorAll("[data-action]").forEach((btn) => {
    btn.addEventListener("click", async (e) => {
      const action = btn.dataset.action;
      if (action === "open-pdf") {
        const path = btn.dataset.path;
        const url = path.match(/^[a-zA-Z]:\\|^\//) ? "file:///" + path.replace(/\\/g, "/") : path;
        chrome.tabs.create({ url });
      } else if (action === "open-maps") {
        chrome.tabs.create({ url: mapsUrl(btn.dataset.query) });
      } else if (action === "open-url") {
        chrome.tabs.create({ url: btn.dataset.url });
      } else if (action === "open-directions") {
        chrome.tabs.create({ url: mapsDirectionsUrl(btn.dataset.dest, { lat: btn.dataset.lat, lon: btn.dataset.lon }) });
      } else if (action === "send-email") {
        chrome.tabs.create({ url: `mailto:${btn.dataset.email}` });
      } else if (action === "call") {
        chrome.tabs.create({ url: `tel:${btn.dataset.phone}` });
      } else if (action === "find-garage-nearby") {
        addBotTicket(buildLocationPromptTicket(btn.dataset.id, btn.dataset.requireBrand || null));
      } else if (action === "geo-locate") {
        const requireBrand = btn.dataset.requireBrand || null;
        btn.disabled = true;
        btn.textContent = "📍 Localisation en cours…";
        try {
          const position = await GarageFinder.getBrowserPosition();
          await runGarageSearch(btn.dataset.id, position, requireBrand);
        } catch (err) {
          addBotPlainMessage(err.message);
        } finally {
          btn.disabled = false;
          btn.textContent = "📍 Utiliser ma position";
        }
      } else if (action === "geo-search-city") {
        const requireBrand = btn.dataset.requireBrand || null;
        const ticket = btn.closest(".ticket");
        const input = ticket?.querySelector(".gf-city-input");
        const city = input?.value.trim();
        if (!city) {
          input?.focus();
          return;
        }
        btn.disabled = true;
        btn.textContent = "Recherche…";
        try {
          const position = await GarageFinder.geocodeCity(city);
          await runGarageSearch(btn.dataset.id, position, requireBrand);
        } catch (err) {
          addBotPlainMessage(err.message);
        } finally {
          btn.disabled = false;
          btn.textContent = "Rechercher";
        }
      } else if (action === "book-rdv-garage") {
        const text = `Demande de rendez-vous — ${btn.dataset.name}\nVéhicule : ${btn.dataset.vehicle}\nTéléphone du garage : ${btn.dataset.phone || "—"}`;
        await navigator.clipboard.writeText(text);
        btn.textContent = "✅ Copié";
        setTimeout(() => (btn.textContent = "📅 Prendre RDV"), 1400);
      } else if (action === "book-rdv") {
        const agreement = await Store.getAgreement(btn.dataset.id);
        if (agreement) {
          const v = vehicleContext.vehicle;
          const text = `Demande de rendez-vous — ${agreement.provider}\nVéhicule : ${v ? `${v.plate} — ${v.brand || ""} ${v.model || ""}`.trim() : "—"}\nCatégorie : ${agreement.category || "—"}\nTéléphone : ${agreement.phone || "—"}`;
          await navigator.clipboard.writeText(text);
          btn.textContent = "✅ Copié";
          setTimeout(() => (btn.textContent = "📅 Prendre RDV"), 1400);
        }
      } else if (action === "copy-info") {
        const agreement = await Store.getAgreement(btn.dataset.id);
        if (agreement) {
          const text = `${agreement.provider} — ${agreement.category}\nRemise : ${agreement.discount || "—"}\nConditions : ${agreement.conditions || "—"}\nContrat : ${agreement.pdfPath || "—"}`;
          await navigator.clipboard.writeText(text);
          btn.textContent = "✅ Copié";
          setTimeout(() => (btn.textContent = "📋 Copier"), 1400);
        }
      } else if (action === "toggle-pin") {
        await Store.togglePin(btn.dataset.id);
        const agreement = await Store.getAgreement(btn.dataset.id);
        btn.textContent = agreement.pinned ? "★ Épinglé" : "☆ Épingler";
      } else if (action === "toggle-full-discount") {
        const ticket = btn.closest(".ticket");
        const panel = ticket?.querySelector("[data-full-discount]");
        if (!panel) return;
        if (panel.classList.contains("hidden")) {
          if (!panel.dataset.loaded) {
            const agreement = await Store.getAgreement(btn.dataset.id);
            panel.textContent = agreement?.discount || "";
            panel.dataset.loaded = "1";
          }
          panel.classList.remove("hidden");
          btn.textContent = "📊 Masquer le détail";
        } else {
          panel.classList.add("hidden");
          btn.textContent = "📊 Voir tout le détail";
        }
      } else if (action === "select-vehicle") {
        const vehicle = await Store.getVehicle(btn.dataset.id);
        if (vehicle) {
          await selectVehicle(vehicle);
          addBotPlainMessage(`Fiche d'exploitation chargée pour ${vehicle.client || "ce client"}.`);
        }
      }
    });
  });
}

// ---------------- Cartes de réponse liées au véhicule ----------------

function buildInfoTicket({ status = "info", icon, eyebrow, title, rows = [], footerNote }) {
  const ic = icon || (status === "success" ? "🟢" : status === "danger" ? "❌" : "🔵");
  return `
    <div class="ticket status-${status}">
      <div class="ticket-header status-${status}">${ic} ${escapeHtml(eyebrow)}</div>
      ${title ? `<div class="ticket-title">${title}</div>` : ""}
      ${rows.map((r) => `<div class="ticket-row"><span class="check">✔</span> ${r}</div>`).join("")}
      ${footerNote ? `<div class="ticket-conditions">${escapeHtml(footerNote)}</div>` : ""}
    </div>
  `;
}

function buildVehicleFoundTicket(vehicle, fiche) {
  const ticket = buildInfoTicket({
    status: "success",
    icon: "🚗",
    eyebrow: "Véhicule trouvé",
    rows: [
      vehicle.client ? `Client : <strong>${escapeHtml(vehicle.client)}</strong>` : null,
      vehicle.brand || vehicle.model ? `${escapeHtml([vehicle.brand, vehicle.model, vehicle.year ? `(${vehicle.year})` : null].filter(Boolean).join(" "))}` : null,
      vehicle.engine ? `Motorisation : ${escapeHtml(vehicle.engine)}` : null,
      vehicle.renter ? `Loueur : <strong>${escapeHtml(vehicle.renter)}</strong>` : null,
      vehicle.center ? `Centre : ${escapeHtml(vehicle.center)}` : null,
    ].filter(Boolean),
    footerNote: fiche ? "Fiche d'exploitation chargée." : "Aucune fiche d'exploitation associée à ce client pour le moment.",
  });
  const action = `<div style="margin-top:8px;"><button class="btn btn-ghost" data-action="find-garage-nearby" data-id="${vehicle.id}">🔍 Trouver un garage pour l'entretien</button></div>`;
  return ticket + action;
}

function buildVehicleNotFoundTicket(plate) {
  return buildInfoTicket({
    status: "danger",
    eyebrow: "Véhicule introuvable",
    rows: [`Aucune fiche véhicule enregistrée pour <strong>${escapeHtml(plate)}</strong>.`],
    footerNote: "Ajoutez ce véhicule depuis ⚙ Administration → Véhicules.",
  });
}

function buildNoFicheTicket() {
  return buildInfoTicket({
    status: "danger",
    eyebrow: "Information manquante",
    rows: ["Cette information n'est pas renseignée sur la fiche d'exploitation du client."],
    footerNote: "Complétez la fiche depuis ⚙ Administration → Fiches clients.",
  });
}

function buildPlafondTicket(fiche) {
  return buildInfoTicket({
    status: "info",
    icon: "💰",
    eyebrow: "Validation",
    rows: [
      `Le plafond sans accord client est de <strong>${SearchEngine.fmtEuros(fiche.plafond)}</strong>.`,
      fiche.validateurNom ? `Validateur : <strong>${escapeHtml(fiche.validateurNom)}</strong>` : null,
      fiche.validateurCanal ? `Canal : ${escapeHtml(fiche.validateurCanal)}` : null,
    ].filter(Boolean),
    footerNote: "Au-delà de ce montant, un accord écrit du responsable flotte est obligatoire.",
  });
}

function buildDevisCheckTicket({ amount, overCeiling, fiche, needsAmount }) {
  if (needsAmount) {
    return buildInfoTicket({
      status: "info",
      eyebrow: "Montant du devis",
      rows: [`Précisez le montant du devis (ex : « devis de 950 € ») pour vérifier s'il dépasse le plafond de ${SearchEngine.fmtEuros(fiche.plafond)}.`],
    });
  }
  if (!overCeiling) {
    return buildInfoTicket({
      status: "success",
      eyebrow: "Dans les clous",
      rows: [`✅ Devis de <strong>${SearchEngine.fmtEuros(amount)}</strong> : sous le plafond de ${SearchEngine.fmtEuros(fiche.plafond)}, les travaux peuvent être lancés.`],
    });
  }
  return buildInfoTicket({
    status: "danger",
    eyebrow: "Accord obligatoire",
    rows: [
      `❌ Le montant (<strong>${SearchEngine.fmtEuros(amount)}</strong>) dépasse le plafond autorisé de ${SearchEngine.fmtEuros(fiche.plafond)}.`,
      fiche.validateurNom ? `Validateur : <strong>${escapeHtml(fiche.validateurNom)}</strong>` : null,
      fiche.validateurCanal ? `Canal : ${escapeHtml(fiche.validateurCanal)}` : null,
    ].filter(Boolean),
  });
}

function buildFicheFieldTicket(intentType, fiche) {
  const configs = {
    controle_technique: {
      icon: "🔧", eyebrow: "Contrôle technique",
      rows: [
        fiche.controleTechnique.centre ? `Centre conseillé : <strong>${escapeHtml(fiche.controleTechnique.centre)}</strong>` : null,
        fiche.controleTechnique.frequence ? `Fréquence : ${escapeHtml(fiche.controleTechnique.frequence)}` : null,
        fiche.controleTechnique.notes ? escapeHtml(fiche.controleTechnique.notes) : null,
      ],
    },
    assistance: {
      icon: "📞", eyebrow: "Assistance",
      rows: [
        fiche.assistance.telephone ? `Numéro d'assistance : <strong>${escapeHtml(fiche.assistance.telephone)}</strong>` : null,
        fiche.assistance.notes ? escapeHtml(fiche.assistance.notes) : null,
      ],
    },
    vehicule_relais: {
      icon: "🚙", eyebrow: "Véhicule relais",
      rows: [
        `Véhicule relais : <strong>${fiche.vehiculeRelais.autorise ? "Autorisé" : "Non autorisé"}</strong>`,
        fiche.vehiculeRelais.notes ? escapeHtml(fiche.vehiculeRelais.notes) : null,
      ],
    },
    garantie: {
      icon: "🛡️", eyebrow: "Garantie",
      rows: [fiche.garantie.notes ? escapeHtml(fiche.garantie.notes) : "Aucune information complémentaire."],
    },
    facturation: {
      icon: "🧾", eyebrow: "Facturation",
      rows: [
        fiche.facturation.destinataire ? `Qui reçoit les factures : <strong>${escapeHtml(fiche.facturation.destinataire)}</strong>` : null,
        fiche.facturation.email ? `E-mail : ${escapeHtml(fiche.facturation.email)}` : null,
        fiche.facturation.notes ? escapeHtml(fiche.facturation.notes) : null,
      ],
    },
    assurance: {
      icon: "🛡️", eyebrow: "Assurance",
      rows: [
        fiche.assurance.compagnie ? `Compagnie : <strong>${escapeHtml(fiche.assurance.compagnie)}</strong>` : null,
        fiche.assurance.telephone ? `Téléphone : ${escapeHtml(fiche.assurance.telephone)}` : null,
        fiche.assurance.notes ? escapeHtml(fiche.assurance.notes) : null,
      ],
    },
    carte_carburant: {
      icon: "⛽", eyebrow: "Cartes carburant",
      rows: [fiche.cartesCarburant.notes ? escapeHtml(fiche.cartesCarburant.notes) : "Aucune information complémentaire."],
    },
    peage: {
      icon: "🛣️", eyebrow: "Péages",
      rows: [fiche.peages.notes ? escapeHtml(fiche.peages.notes) : "Aucune information complémentaire."],
    },
    contact: {
      icon: "☎️", eyebrow: "Contacts",
      rows: (fiche.contacts || []).map((c) => `${escapeHtml(c.label)} : <strong>${escapeHtml(c.value)}</strong>`),
    },
  };
  const cfg = configs[intentType];
  if (!cfg) return buildNoFicheTicket();
  return buildInfoTicket({ status: "info", icon: cfg.icon, eyebrow: cfg.eyebrow, rows: cfg.rows.filter(Boolean) });
}

function buildContratTicket(vehicle) {
  return buildInfoTicket({
    status: "info",
    icon: "📄",
    eyebrow: "Contrat",
    rows: [
      vehicle.renter ? `Loueur : <strong>${escapeHtml(vehicle.renter)}</strong>` : null,
      vehicle.contractRef ? `Référence contrat : ${escapeHtml(vehicle.contractRef)}` : null,
      !vehicle.contractPath ? "Aucun fichier de contrat renseigné sur la fiche véhicule." : null,
    ].filter(Boolean),
    footerNote: vehicle.contractPath ? undefined : "Ajoutez le chemin du contrat depuis ⚙ Administration → Véhicules.",
  }) + (vehicle.contractPath
    ? `<div style="margin-top:8px;"><button class="btn btn-ghost" data-action="open-pdf" data-path="${escapeHtml(vehicle.contractPath)}">📂 Ouvrir le contrat</button></div>`
    : "");
}

// ---------------- Recherche de garage à proximité ----------------

function mapsDirectionsUrl(destQuery, origin) {
  const base = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destQuery)}`;
  return origin ? `${base}&origin=${origin.lat},${origin.lon}` : base;
}

function buildLocationPromptTicket(vehicleId, requireBrand) {
  const note = requireBrand
    ? `<div class="ticket-row" style="color:var(--text-faint); font-size:12px;">🔒 Recherche restreinte aux concessions <strong>${escapeHtml(requireBrand)}</strong> (règle imposée).</div>`
    : "";
  return `
    <div class="ticket status-info">
      <div class="ticket-header status-info">📍 Localisation</div>
      <div class="ticket-row">Indiquez votre ville, ou autorisez la géolocalisation, pour trouver les garages les plus proches.</div>
      ${note}
      <div style="display:flex; gap:6px; margin-top:8px;">
        <input type="text" class="gf-city-input" placeholder="Ex : Gennevilliers" style="flex:1; background:var(--surface-2); border:1px solid var(--border); color:var(--text); border-radius:var(--radius); padding:8px 10px; font-size:13px;" />
        <button class="btn btn-primary" data-action="geo-search-city" data-id="${vehicleId}" data-require-brand="${escapeHtml(requireBrand || "")}">Rechercher</button>
      </div>
      <div style="margin-top:8px;">
        <button class="btn btn-ghost" data-action="geo-locate" data-id="${vehicleId}" data-require-brand="${escapeHtml(requireBrand || "")}">📍 Utiliser ma position</button>
      </div>
    </div>
  `;
}

function garageReasonBadgeColor(reason) {
  if (reason === "Concession officielle") return "success";
  if (reason === "Prestataire négocié") return "success";
  if (reason === "Spécialiste de la marque") return "info";
  return "info";
}

function buildGarageResultsHtml(garages, position, vehicle, requireBrand) {
  const offsetDeg = 0.07; // ~7-8 km de rayon visible, approximatif
  const bbox = [position.lon - offsetDeg, position.lat - offsetDeg, position.lon + offsetDeg, position.lat + offsetDeg].join(",");
  const mapUrl = `https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${position.lat},${position.lon}`;

  const restrictionNote = requireBrand
    ? `<div style="font-size:11px; color:var(--text-faint); margin-top:2px; padding: 0 6px;">🔒 Résultats filtrés : concessions <strong>${escapeHtml(requireBrand)}</strong> uniquement (règle imposée).</div>`
    : "";

  const mapBlock = `
    <div class="ticket status-info" style="padding:8px;">
      <iframe src="${mapUrl}" style="width:100%; height:150px; border:0; border-radius:8px;" loading="lazy"></iframe>
      <div style="font-size:11px; color:var(--text-faint); margin-top:6px; padding: 0 6px;">
        Carte centrée sur votre position (${escapeHtml(position.label || "position actuelle")}). Les épingles individuelles par garage ne
        sont pas affichées ici (nécessiterait une clé Google Maps payante) — utilisez « 🧭 Itinéraire » sur chaque résultat pour l'ouvrir précisément.
      </div>
      ${restrictionNote}
    </div>`;

  if (!garages.length) {
    return mapBlock + `
      <div class="ticket status-danger">
        <div class="ticket-row">${requireBrand ? `Aucune concession ${escapeHtml(requireBrand)} trouvée dans un rayon de 15 km via OpenStreetMap. Essayez une ville plus grande à proximité.` : "Aucun garage trouvé dans un rayon de 15 km via OpenStreetMap. Essayez une ville plus grande à proximité, ou complétez vos propres accords fournisseurs."}</div>
      </div>`;
  }

  const cards = garages
    .map((g) => {
      const statusClass = garageReasonBadgeColor(g.reason);
      const destQuery = g.address || g.name;
      return `
      <div class="ticket status-${statusClass}">
        <div class="ticket-header status-${statusClass}">🔧 ${escapeHtml(g.reason)} · ${g.distanceKm.toFixed(1)} km</div>
        <div class="ticket-title">${escapeHtml(g.name)}</div>
        ${g.address ? `<div class="ticket-row"><span class="check">✔</span> ${escapeHtml(g.address)}</div>` : `<div class="ticket-row" style="color:var(--text-faint);">Adresse non renseignée dans OpenStreetMap</div>`}
        ${g.hours ? `<div class="ticket-row"><span class="check">✔</span> Horaires : ${escapeHtml(g.hours)}</div>` : ""}
        ${g.brandTag ? `<div class="ticket-row"><span class="check">✔</span> Marques : ${escapeHtml(g.brandTag)}</div>` : ""}
        ${g.negotiatedAgreement ? `<div class="ticket-conditions">Accord négocié : ${escapeHtml(g.negotiatedAgreement.discount || g.negotiatedAgreement.conditions || "voir votre fiche prestataire")}</div>` : ""}
        <div class="ticket-row" style="color:var(--text-faint); font-size:12px;">Note clients : non communiquée par cette source gratuite —
          <button class="btn btn-ghost" style="padding:2px 6px; font-size:11.5px;" data-action="open-url" data-url="https://www.google.com/maps/search/${encodeURIComponent(g.name + " " + (g.address || ""))}">voir sur Google Maps</button>
        </div>
        <div class="ticket-footer">
          <span class="pill">${escapeHtml(g.source === "osm" ? "OpenStreetMap" : "Négocié")}</span>
          <div class="ticket-actions">
            ${g.phone ? `<button class="btn btn-ghost" data-action="call" data-phone="${escapeHtml(g.phone)}">📞 Appeler</button>` : ""}
            ${g.email ? `<button class="btn btn-ghost" data-action="send-email" data-email="${escapeHtml(g.email)}">✉️ E-mail</button>` : ""}
            ${g.website ? `<button class="btn btn-ghost" data-action="open-url" data-url="${escapeHtml(g.website)}">🌐 Site</button>` : ""}
            <button class="btn btn-ghost" data-action="open-directions" data-dest="${escapeHtml(destQuery)}" data-lat="${position.lat}" data-lon="${position.lon}">🧭 Itinéraire</button>
            <button class="btn btn-ghost" data-action="book-rdv-garage" data-name="${escapeHtml(g.name)}" data-phone="${escapeHtml(g.phone || "")}" data-vehicle="${escapeHtml(vehicle.plate)}">📅 Prendre RDV</button>
          </div>
        </div>
      </div>`;
    })
    .join("");

  return mapBlock + cards;
}

async function runGarageSearch(vehicleId, position, requireBrand) {
  const vehicle = await Store.getVehicle(vehicleId);
  if (!vehicle) return;
  const loadingRow = document.createElement("div");
  loadingRow.className = "msg-row bot";
  loadingRow.innerHTML = `<div class="ticket status-info"><div class="ticket-row">🔎 Recherche des garages autour de ${escapeHtml(position.label || "votre position")}…</div></div>`;
  els.messages.appendChild(loadingRow);
  scrollToBottom();

  try {
    const agreements = await Store.listAgreements();
    const garages = await GarageFinder.findGarages({ position, vehicle, agreements, requireBrand: requireBrand || null });
    loadingRow.remove();
    addBotTicket(buildGarageResultsHtml(garages, position, vehicle, requireBrand));
  } catch (err) {
    loadingRow.remove();
    addBotPlainMessage(err.message || "La recherche de garages a échoué. Réessayez dans un instant.");
  }
}

function buildExclusiveGarageTicket(result, vehicle) {
  if (result.agreement) {
    const label = result.reason === "brand_rule" ? `Concession ${vehicle.brand} imposée` : "Prestataire imposé par le client";
    const explain =
      result.reason === "brand_rule"
        ? `Aucune alternative proposée : règle imposée pour tous les véhicules ${escapeHtml(vehicle.brand || "")}.`
        : "Aucune alternative proposée : règle imposée pour ce client.";
    return (
      buildTicketHtml(result.agreement, {
        status: "info",
        eyebrow: `🔒 ${label}`,
        relevantDiscount: result.relevantDiscount,
        vehicleActions: true,
      }) + `<div class="ticket-conditions" style="margin:-4px 0 0;">${explain}</div>`
    );
  }
  // Règle exclusive mais aucun accord local enregistré pour cette marque.
  return (
    buildInfoTicket({
      status: "danger",
      icon: "🔒",
      eyebrow: `Concession ${escapeHtml(vehicle.brand || "")} imposée`,
      rows: [`Aucun accord n'est enregistré avec un concessionnaire ${escapeHtml(vehicle.brand || "")}.`],
      footerNote: "Ajoutez-le depuis ⚙ Administration → Accords, ou lancez la recherche à proximité ci-dessous (filtrée sur cette marque).",
    }) +
    `<div style="margin-top:8px;"><button class="btn btn-ghost" data-action="find-garage-nearby" data-id="${vehicle.id}" data-require-brand="${escapeHtml(vehicle.brand || "")}">🔍 Chercher une concession ${escapeHtml(vehicle.brand || "")} à proximité</button></div>`
  );
}

async function handleVehicleResult(result) {
  const { vehicle, fiche } = result;
  switch (result.type) {
    case "find_garage_nearby":
      if (result.ficheExclusiveAgreement) {
        addBotTicket(
          buildTicketHtml(result.ficheExclusiveAgreement, {
            status: "info",
            eyebrow: "🔒 Prestataire imposé par le client",
            vehicleActions: true,
          }) + `<div class="ticket-conditions" style="margin:-4px 0 0;">Aucune alternative proposée : ce client doit utiliser ce prestataire pour l'entretien.</div>`
        );
        return;
      }
      addBotTicket(buildLocationPromptTicket(vehicle.id, result.brandRule ? vehicle.brand : null));
      return;
    case "no_fiche":
      addBotTicket(buildNoFicheTicket());
      return;
    case "plafond":
      addBotTicket(buildPlafondTicket(fiche));
      return;
    case "devis_check":
      addBotTicket(buildDevisCheckTicket(result));
      return;
    case "controle_technique":
    case "assistance":
    case "vehicule_relais":
    case "garantie":
    case "facturation":
    case "assurance":
    case "carte_carburant":
    case "peage":
    case "contact":
      addBotTicket(buildFicheFieldTicket(result.type, fiche));
      return;
    case "contrat":
      addBotTicket(buildContratTicket(vehicle));
      return;
    case "garage":
      if (result.exclusive) {
        addBotTicket(buildExclusiveGarageTicket(result, vehicle));
      } else {
        addBotTicket(
          buildTicketHtml(result.agreement, {
            status: result.reason === "fiche_preference" ? "info" : "success",
            eyebrow: result.reason === "fiche_preference" ? "Prestataire préféré du client" : "Prestataire recommandé",
            relevantDiscount: result.relevantDiscount,
            vehicleActions: true,
          })
        );
      }
      return;
    default:
      addBotPlainMessage("Je n'ai pas trouvé de réponse précise pour ce véhicule. Essayez de préciser (pneus, plafond, assistance, contrôle technique…).");
  }
}

async function handleSubmit(e) {
  if (e) e.preventDefault();
  const query = els.chatInput.value.trim();
  if (!query) return;
  els.chatInput.value = "";
  addUserMessage(query);

  // 1) Détection d'une immatriculation dans le message : bascule le
  //    contexte de conversation sur ce véhicule.
  const plate = SearchEngine.extractPlate(query);
  if (plate) {
    const vehicle = await Store.findVehicleByPlate(plate);
    if (!vehicle) {
      await Store.appendHistory({ query, resultType: "vehicle_not_found" });
      addBotTicket(buildVehicleNotFoundTicket(plate));
      return;
    }
    await selectVehicle(vehicle);
    await Store.appendHistory({ query, resultType: "vehicle_found", agreementId: null });
    addBotTicket(buildVehicleFoundTicket(vehicle, vehicleContext.fiche));
    // Si le message ne contenait que la plaque, on s'arrête là : les
    // questions suivantes porteront sur ce véhicule.
    if (SearchEngine.isPlateOnlyInput(query, plate)) return;
    // Sinon, le reste du message peut contenir une vraie question : on
    // continue avec le contexte véhicule fraîchement chargé.
  }

  // 2) Un véhicule est sélectionné : on tente une réponse "métier" avant
  //    de retomber sur la recherche générique d'accords.
  if (vehicleContext.vehicle) {
    const agreementsForVehicle = await Store.listAgreements();
    const brandRules = await Store.listBrandRules();
    const vResult = SearchEngine.resolveVehicleQuery({
      query,
      vehicle: vehicleContext.vehicle,
      fiche: vehicleContext.fiche,
      agreements: agreementsForVehicle,
      brandRules,
    });
    if (vResult.type !== "vehicle_unresolved") {
      await Store.appendHistory({ query, resultType: vResult.type, agreementId: vResult.agreement?.id || null });
      await handleVehicleResult(vResult);
      return;
    }
    // "vehicle_unresolved" : on retente en recherche générique ci-dessous,
    // sans perdre le véhicule sélectionné.
  }

  // 3) Recherche générique dans les accords fournisseurs (comportement
  //    d'origine de l'extension, conservé tel quel).
  const agreements = await Store.listAgreements();
  const result = SearchEngine.resolveQuery(query, agreements);

  await Store.appendHistory({ query, resultType: result.type, agreementId: result.agreement?.id || null });

  if (result.type === "direct_provider" || result.type === "match") {
    addBotTicket(
      buildTicketHtml(result.agreement, {
        status: result.type === "direct_provider" ? "info" : "success",
        eyebrow: result.type === "direct_provider" ? "Réponse directe" : "Prestataire recommandé",
        relevantDiscount: result.relevantDiscount,
        vehicleActions: !!vehicleContext.vehicle,
      })
    );
  } else if (result.type === "no_agreement") {
    if (result.alternative) {
      addBotTicket(
        buildTicketHtml(result.alternative, {
          status: "success",
          eyebrow: "Prestataire recommandé",
          negativeIntro: `❌ Aucun accord commercial n'est enregistré avec « ${escapeHtml(result.mentioned)} ».`,
          relevantDiscount: result.relevantDiscount,
          vehicleActions: !!vehicleContext.vehicle,
        })
      );
    } else {
      addBotPlainMessage(`Aucun accord commercial n'est enregistré avec « ${result.mentioned} », et je n'ai pas trouvé d'alternative pertinente pour cette demande.`);
    }
  } else {
    addBotPlainMessage(
      vehicleContext.vehicle
        ? "Je n'ai pas trouvé de réponse pour ce véhicule. Essayez : pneus, plafond, contrôle technique, assistance, contrat…"
        : "Je n'ai trouvé aucun accord correspondant à votre demande. Essayez de préciser la prestation (pneus, pare-brise, vidange…) ou le nom du prestataire."
    );
  }
}

els.composer.addEventListener("submit", handleSubmit);

// ---------------- Navigation entre vues ----------------
const views = {
  chat: document.getElementById("view-chat"),
  dashboard: document.getElementById("view-dashboard"),
  pinned: document.getElementById("view-pinned"),
  history: document.getElementById("view-history"),
};

function showView(name) {
  Object.values(views).forEach((v) => v.classList.add("hidden"));
  views[name].classList.remove("hidden");
}

document.querySelectorAll("[data-back]").forEach((btn) =>
  btn.addEventListener("click", () => showView("chat"))
);

document.getElementById("adminBtn").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});

document.getElementById("dashboardBtn").addEventListener("click", async () => {
  showView("dashboard");
  const stats = await Store.computeDashboard();
  els.statGrid.innerHTML = `
    <div class="stat-card"><div class="stat-value">${stats.totalAgreements}</div><div class="stat-label">Accords enregistrés</div></div>
    <div class="stat-card"><div class="stat-value">${stats.totalProviders}</div><div class="stat-label">Prestataires</div></div>
    <div class="stat-card"><div class="stat-value">${stats.totalCategories}</div><div class="stat-label">Catégories</div></div>
    <div class="stat-card"><div class="stat-value">${stats.expiringSoon.length}</div><div class="stat-label">Expirent sous 30j</div></div>
  `;
  els.expiringList.innerHTML = stats.expiringSoon.length
    ? stats.expiringSoon
        .map(
          (a) => `
      <div class="list-row">
        <div>
          <div class="list-row-title">${escapeHtml(a.provider)}</div>
          <div class="list-row-sub">Expire le ${formatDate(a.endDate)}</div>
        </div>
        <span class="pill">${escapeHtml(a.category || "")}</span>
      </div>`
        )
        .join("")
    : `<div class="empty-hint">Aucun contrat n'expire dans les 30 prochains jours.</div>`;
});

document.getElementById("pinnedBtn").addEventListener("click", async () => {
  showView("pinned");
  const list = (await Store.listAgreements()).filter((a) => a.pinned);
  els.pinnedList.innerHTML = list.length
    ? list
        .map(
          (a) => `
      <div class="list-row">
        <div>
          <div class="list-row-title">${escapeHtml(a.provider)}</div>
          <div class="list-row-sub">${escapeHtml(a.category || "")} · ${escapeHtml(a.discount || "")}</div>
        </div>
        <button class="btn btn-ghost" data-action="toggle-pin" data-id="${a.id}">★</button>
      </div>`
        )
        .join("")
    : `<div class="empty-hint">Aucun prestataire épinglé pour le moment. Épinglez-en un depuis une réponse du chat.</div>`;
  wireTicketActions(els.pinnedList);
});

document.getElementById("historyBtn").addEventListener("click", async () => {
  showView("history");
  const history = (await Store.listHistory()).slice().reverse();
  els.historyList.innerHTML = history.length
    ? history
        .map(
          (h) => `
      <div class="list-row">
        <div>
          <div class="list-row-title">${escapeHtml(h.query)}</div>
          <div class="list-row-sub">${new Date(h.date).toLocaleString("fr-FR")}</div>
        </div>
        <span class="pill">${h.resultType === "match" || h.resultType === "direct_provider" ? "trouvé" : "sans réponse"}</span>
      </div>`
        )
        .join("")
    : `<div class="empty-hint">Aucune conversation pour le moment.</div>`;
});

document.getElementById("clearHistoryBtn").addEventListener("click", async () => {
  await Store.clearHistory();
  document.getElementById("historyList").innerHTML = `<div class="empty-hint">Historique supprimé.</div>`;
});

// ---------------- Init ----------------
(async function init() {
  await refreshHeader();
  renderSuggestions();
  els.chatInput.focus();
})();
